import Link from "next/link";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { getProducts } from "@/actions/products";
import { formatCurrency } from "@/lib/utils";
import { AdminProductActions } from "./ProductActions";

export const dynamic = "force-dynamic";

export default async function AdminProductsPage() {
  const products = await getProducts();

  return (
    <div className="p-6">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold text-accent">Products</h1>
        <Link href="/admin/products/new" className="btn-primary">
          <Plus size={16} /> New Product
        </Link>
      </div>

      {products.length === 0 ? (
        <div className="card flex flex-col items-center justify-center py-16 text-center">
          <span className="mb-3 text-4xl">📦</span>
          <p className="text-accent-light text-sm">No products yet.</p>
          <Link href="/admin/products/new" className="mt-4 btn-primary">Create First Product</Link>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="border-b border-accent-200 bg-accent-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-accent-light uppercase tracking-wider">Product</th>
                <th className="hidden sm:table-cell px-4 py-3 text-left text-xs font-semibold text-accent-light uppercase tracking-wider">Category</th>
                <th className="hidden md:table-cell px-4 py-3 text-left text-xs font-semibold text-accent-light uppercase tracking-wider">Price(s)</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-accent-light uppercase tracking-wider">Status</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-accent-light uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-accent-200">
              {products.map((product) => (
                <tr key={product.id} className="hover:bg-accent-50 transition-colors">
                  <td className="px-4 py-3">
                    <p className="font-medium text-accent">{product.name_en}</p>
                    <p className="text-xs text-accent-light">{product.name_am}</p>
                  </td>
                  <td className="hidden sm:table-cell px-4 py-3 text-accent-light">
                    {product.category?.name_en ?? "—"}
                  </td>
                  <td className="hidden md:table-cell px-4 py-3 text-accent-light">
                    {product.prices.length > 0
                      ? product.prices.length === 1
                        ? formatCurrency(product.prices[0].price)
                        : `${formatCurrency(Math.min(...product.prices.map(p => p.price)))} – ${formatCurrency(Math.max(...product.prices.map(p => p.price)))}`
                      : "—"}
                  </td>
                  <td className="px-4 py-3">
                    <span className={`badge ${product.is_available ? "bg-green-100 text-green-700" : "bg-red-100 text-red-600"}`}>
                      {product.is_available ? "Available" : "Out of Stock"}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-2">
                      <Link href={`/admin/products/${product.id}/edit`}
                        className="flex h-8 w-8 items-center justify-center rounded-xl text-accent-light hover:bg-secondary hover:text-accent transition">
                        <Pencil size={14} />
                      </Link>
                      <AdminProductActions productId={product.id} />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
