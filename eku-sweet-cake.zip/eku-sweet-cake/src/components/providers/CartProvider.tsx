"use client";

import { useEffect, useState } from "react";

/**
 * CartProvider solves the Zustand + Next.js SSR hydration mismatch:
 * the persisted cart is only available in the browser, so we suppress
 * rendering until after the first client-side paint.
 */
export function CartProvider({ children }: { children: React.ReactNode }) {
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setHydrated(true);
  }, []);

  if (!hydrated) {
    // Render a transparent shell that matches the server HTML to avoid
    // layout shift, but without cart-dependent UI (item count badge, etc.)
    return <>{children}</>;
  }

  return <>{children}</>;
}
