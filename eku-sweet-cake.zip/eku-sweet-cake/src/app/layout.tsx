import type { Metadata, Viewport } from "next";
import { Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import { CartProvider } from "@/components/providers/CartProvider";

const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-jakarta",
  display: "swap",
});

export const metadata: Metadata = {
  title: {
    default: "Eku Sweet Cake",
    template: "%s | Eku Sweet Cake",
  },
  description:
    "Custom birthday cakes, handcrafted chocolates, and juicy burgers — delivered fresh in Addis Ababa.",
  keywords: ["cake", "birthday cake", "burger", "chocolate", "Addis Ababa", "food delivery"],
  authors: [{ name: "Eku Sweet Cake" }],
  creator: "Eku Sweet Cake",
  manifest: "/manifest.json",
  appleWebApp: {
    capable: true,
    statusBarStyle: "default",
    title: "Eku Sweet Cake",
  },
  formatDetection: { telephone: false },
  openGraph: {
    type: "website",
    siteName: "Eku Sweet Cake",
    title: "Eku Sweet Cake",
    description: "Custom birthday cakes, chocolates & burgers — made fresh in Addis Ababa.",
  },
  icons: {
    icon: [
      { url: "/icons/icon-192x192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512x512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: [{ url: "/icons/apple-touch-icon.png" }],
    shortcut: "/favicon.ico",
  },
};

export const viewport: Viewport = {
  themeColor: "#FF6B6B",
  width: "device-width",
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className={`${jakarta.variable}`}>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        {/* Noto Sans Ethiopic for Amharic text — loaded separately so the
            Latin font doesn't wait on it. */}
        <link
          href="https://fonts.googleapis.com/css2?family=Noto+Sans+Ethiopic:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="bg-secondary font-sans antialiased">
        <CartProvider>{children}</CartProvider>
        <script
          dangerouslySetInnerHTML={{
            __html: `if ('serviceWorker' in navigator) { window.addEventListener('load', () => { navigator.serviceWorker.register('/sw.js'); }); }`,
          }}
        />
      </body>
    </html>
  );
}
