import { getDashboardStats } from "@/actions/orders";
import { formatCurrency } from "@/lib/utils";
import {
  ShoppingBag,
  Clock,
  CheckCircle2,
  TrendingUp,
  Calendar,
} from "lucide-react";

export const dynamic = "force-dynamic";

export default async function DashboardPage() {
  const stats = await getDashboardStats();

  const cards = [
    {
      label: "Today's Orders",
      value: stats.todaysOrders,
      icon: ShoppingBag,
      color: "bg-blue-50 text-blue-600",
    },
    {
      label: "Pending Orders",
      value: stats.pendingOrders,
      icon: Clock,
      color: "bg-yellow-50 text-yellow-600",
    },
    {
      label: "Delivered",
      value: stats.deliveredOrders,
      icon: CheckCircle2,
      color: "bg-green-50 text-green-600",
    },
    {
      label: "Revenue Today",
      value: formatCurrency(stats.revenueToday),
      icon: TrendingUp,
      color: "bg-primary/10 text-primary",
    },
    {
      label: "Revenue This Month",
      value: formatCurrency(stats.revenueThisMonth),
      icon: Calendar,
      color: "bg-purple-50 text-purple-600",
    },
  ];

  return (
    <div className="p-6">
      <h1 className="mb-6 text-2xl font-bold text-accent">Dashboard</h1>

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {cards.map((card) => (
          <div key={card.label} className="card p-5 flex flex-col gap-3">
            <div className={`flex h-10 w-10 items-center justify-center rounded-2xl ${card.color}`}>
              <card.icon size={20} />
            </div>
            <div>
              <p className="text-xs text-accent-light font-medium">{card.label}</p>
              <p className="text-xl font-bold text-accent mt-0.5">{card.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <a href="/admin/orders" className="card p-5 flex items-center gap-3 hover:shadow-soft transition-shadow">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-secondary">
            <ShoppingBag size={18} className="text-primary" />
          </div>
          <div>
            <p className="font-bold text-accent text-sm">Manage Orders</p>
            <p className="text-xs text-accent-light">View and update order statuses</p>
          </div>
        </a>
        <a href="/admin/products" className="card p-5 flex items-center gap-3 hover:shadow-soft transition-shadow">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-secondary">
            <span className="text-lg">🛍️</span>
          </div>
          <div>
            <p className="font-bold text-accent text-sm">Manage Products</p>
            <p className="text-xs text-accent-light">Add, edit, or remove products</p>
          </div>
        </a>
        <a href="/admin/settings" className="card p-5 flex items-center gap-3 hover:shadow-soft transition-shadow">
          <div className="flex h-10 w-10 items-center justify-center rounded-2xl bg-secondary">
            <span className="text-lg">⚙️</span>
          </div>
          <div>
            <p className="font-bold text-accent text-sm">Settings</p>
            <p className="text-xs text-accent-light">Payment methods & numbers</p>
          </div>
        </a>
      </div>
    </div>
  );
}
