import type { Order, OrderItem } from "@/types/database";

const PAYMENT_LABELS: Record<string, string> = {
  cod: "Cash on Delivery",
  telebirr: "Telebirr",
  cbe_birr: "CBE Birr",
};

interface OrderWithItems extends Order {
  items: OrderItem[];
}

function buildMessage(order: OrderWithItems): string {
  const lines: string[] = [
    `🔔 *New Order #${order.order_number}*`,
    ``,
    `👤 *Customer:* ${order.customer_name}`,
    `📞 *Phone:* ${order.customer_phone}`,
    `📍 *Address:* ${order.delivery_address}`,
    `💳 *Payment:* ${PAYMENT_LABELS[order.payment_method] ?? order.payment_method}`,
    ``,
    `🛒 *Items:*`,
  ];

  for (const item of order.items) {
    lines.push(`  • ${item.product_name_en} ×${item.quantity} — ${item.unit_price} ETB`);
    if (item.price_label) lines.push(`    Size: ${item.price_label}`);
    if (item.cake_message) lines.push(`    Cake Message: _${item.cake_message}_`);
    if (item.schedule_date)
      lines.push(`    Delivery Date: ${item.schedule_date}`);
  }

  lines.push(``);
  lines.push(`💰 *Order Total:* ${order.total} ETB`);

  if (order.additional_note) {
    lines.push(``);
    lines.push(`📝 *Note:* ${order.additional_note}`);
  }

  return lines.join("\n");
}

/**
 * Send an order notification to the configured Telegram chat.
 * Silently logs the error rather than failing the checkout if Telegram
 * credentials are not configured.
 */
export async function sendOrderNotification(order: OrderWithItems): Promise<void> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    console.warn(
      "[Telegram] TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID not set — skipping notification."
    );
    return;
  }

  const text = buildMessage(order);

  try {
    const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        chat_id: chatId,
        text,
        parse_mode: "Markdown",
      }),
    });

    if (!res.ok) {
      const body = await res.text();
      console.error(`[Telegram] API error ${res.status}: ${body}`);
    }
  } catch (err) {
    console.error("[Telegram] Failed to send notification:", err);
  }
}
