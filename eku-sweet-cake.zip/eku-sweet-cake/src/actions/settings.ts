"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { settingsSchema, adminSignInSchema } from "@/lib/validations";
import type { ActionResult, PaymentSettings } from "@/types/database";

// ── Settings ─────────────────────────────────────────────────────────────────

export async function getSettings(): Promise<PaymentSettings> {
  const supabase = await createClient();
  const { data } = await supabase.from("settings").select("*");

  const map = Object.fromEntries((data ?? []).map((s) => [s.key, s.value]));

  return {
    codEnabled: map["cod_enabled"] !== "false",
    telebirrEnabled: map["telebirr_enabled"] !== "false",
    cbeEnabled: map["cbe_enabled"] !== "false",
    telebirrNumber: map["telebirr_number"] ?? "",
    cbeNumber: map["cbe_number"] ?? "",
  };
}

export async function updateSettings(
  input: Partial<{
    codEnabled: boolean;
    telebirrEnabled: boolean;
    cbeEnabled: boolean;
    telebirrNumber: string;
    cbeNumber: string;
  }>
): Promise<ActionResult> {
  const parsed = settingsSchema.partial().safeParse(input);
  if (!parsed.success) {
    return { success: false, error: parsed.error.errors[0]?.message ?? "Validation failed." };
  }

  const supabase = await createClient();

  const pairs: { key: string; value: string }[] = [];
  const d = parsed.data;

  if (d.codEnabled !== undefined) pairs.push({ key: "cod_enabled", value: String(d.codEnabled) });
  if (d.telebirrEnabled !== undefined) pairs.push({ key: "telebirr_enabled", value: String(d.telebirrEnabled) });
  if (d.cbeEnabled !== undefined) pairs.push({ key: "cbe_enabled", value: String(d.cbeEnabled) });
  if (d.telebirrNumber !== undefined) pairs.push({ key: "telebirr_number", value: d.telebirrNumber });
  if (d.cbeNumber !== undefined) pairs.push({ key: "cbe_number", value: d.cbeNumber });

  for (const pair of pairs) {
    const { error } = await supabase
      .from("settings")
      .upsert({ key: pair.key, value: pair.value }, { onConflict: "key" });
    if (error) return { success: false, error: error.message };
  }

  revalidatePath("/admin/settings");
  revalidatePath("/checkout");
  return { success: true, data: undefined };
}

// ── Auth ──────────────────────────────────────────────────────────────────────

export async function adminSignIn(input: {
  email: string;
  password: string;
}): Promise<ActionResult> {
  const parsed = adminSignInSchema.safeParse(input);
  if (!parsed.success) {
    return { success: false, error: parsed.error.errors[0]?.message ?? "Invalid credentials." };
  }

  const supabase = await createClient();
  const { error } = await supabase.auth.signInWithPassword({
    email: parsed.data.email,
    password: parsed.data.password,
  });

  if (error) return { success: false, error: "Invalid email or password." };

  // Verify the user is actually in the admins table
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return { success: false, error: "Authentication failed." };

  const { data: adminRow } = await supabase
    .from("admins")
    .select("id")
    .eq("id", user.id)
    .single();

  if (!adminRow) {
    await supabase.auth.signOut();
    return { success: false, error: "Access denied — you are not an admin." };
  }

  return { success: true, data: undefined };
}

export async function adminSignOut(): Promise<void> {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/admin/login");
}

export async function getAdminUser() {
  const supabase = await createClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();
  return user;
}
