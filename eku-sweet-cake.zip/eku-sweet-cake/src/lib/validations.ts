import { z } from "zod";

// ── Checkout ─────────────────────────────────────────────────────────────────
export const checkoutSchema = z.object({
  customerName: z
    .string()
    .min(2, "Full name must be at least 2 characters.")
    .max(100, "Full name is too long."),
  customerPhone: z
    .string()
    .regex(/^(\+2519|09)\d{8}$/, "Enter a valid Ethiopian phone number (09xxxxxxxx)."),
  deliveryAddress: z
    .string()
    .min(5, "Please enter a complete delivery address.")
    .max(300, "Address is too long."),
  additionalNote: z.string().max(500).optional().default(""),
  paymentMethod: z.enum(["cod", "telebirr", "cbe_birr"]),
});

export type CheckoutInput = z.infer<typeof checkoutSchema>;

// ── Category ─────────────────────────────────────────────────────────────────
export const categorySchema = z.object({
  nameEn: z.string().min(1, "Name (English) is required.").max(80),
  nameAm: z.string().min(1, "Name (Amharic) is required.").max(80),
  slug: z
    .string()
    .min(1, "Slug is required.")
    .max(80)
    .regex(/^[a-z0-9]+(-[a-z0-9]+)*$/, "Slug must be lowercase letters, numbers and hyphens only."),
  descriptionEn: z.string().max(500).optional().default(""),
  descriptionAm: z.string().max(500).optional().default(""),
  sortOrder: z.coerce.number().int().min(0).default(0),
  isActive: z.boolean().default(true),
});

export type CategoryInput = z.infer<typeof categorySchema>;

// ── Product ──────────────────────────────────────────────────────────────────
export const priceOptionSchema = z.object({
  id: z.string().optional(),
  label: z.string().min(1, "Label is required.").max(80),
  price: z.coerce.number().positive("Price must be positive."),
  sortOrder: z.coerce.number().int().min(0).default(0),
});

export const productSchema = z.object({
  categoryId: z.string().uuid("Please select a category."),
  nameEn: z.string().min(1, "Name (English) is required.").max(120),
  nameAm: z.string().min(1, "Name (Amharic) is required.").max(120),
  descriptionEn: z.string().max(1000).optional().default(""),
  descriptionAm: z.string().max(1000).optional().default(""),
  isAvailable: z.boolean().default(true),
  requireMessage: z.boolean().default(false),
  requireScheduleDate: z.boolean().default(false),
  requireAdvancePayment: z.boolean().default(false),
  minimumNoticeDays: z.coerce.number().int().min(0).max(60).default(0),
  sortOrder: z.coerce.number().int().min(0).default(0),
  prices: z.array(priceOptionSchema).min(1, "At least one price option is required."),
});

export type ProductInput = z.infer<typeof productSchema>;

// ── Settings ─────────────────────────────────────────────────────────────────
export const settingsSchema = z.object({
  codEnabled: z.boolean().default(true),
  telebirrEnabled: z.boolean().default(true),
  cbeEnabled: z.boolean().default(true),
  telebirrNumber: z.string().max(20).optional().default(""),
  cbeNumber: z.string().max(20).optional().default(""),
});

export type SettingsInput = z.infer<typeof settingsSchema>;

// ── Order status update (admin) ───────────────────────────────────────────────
export const updateOrderStatusSchema = z.object({
  orderId: z.string().uuid(),
  status: z.enum([
    "pending",
    "confirmed",
    "preparing",
    "out_for_delivery",
    "delivered",
    "cancelled",
  ]),
});

export type UpdateOrderStatusInput = z.infer<typeof updateOrderStatusSchema>;

// ── Admin sign-in ─────────────────────────────────────────────────────────────
export const adminSignInSchema = z.object({
  email: z.string().email("Enter a valid email address."),
  password: z.string().min(6, "Password must be at least 6 characters."),
});

export type AdminSignInInput = z.infer<typeof adminSignInSchema>;
