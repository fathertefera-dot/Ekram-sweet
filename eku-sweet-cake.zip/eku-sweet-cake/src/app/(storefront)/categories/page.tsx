import Link from "next/link";
import Image from "next/image";
import type { Metadata } from "next";
import { getActiveCategories } from "@/actions/categories";

export const metadata: Metadata = { title: "Categories" };
export const dynamic = "force-dynamic";

export default async function CategoriesPage() {
  const categories = await getActiveCategories();

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <h1 className="mb-6 text-2xl font-bold text-accent">All Categories</h1>

      {categories.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <span className="mb-3 text-5xl">🍽️</span>
          <p className="text-accent-light">No categories yet. Check back soon!</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {categories.map((cat) => (
            <Link
              key={cat.id}
              href={`/categories/${cat.slug}`}
              className="card group flex flex-col items-center gap-4 p-6 text-center transition-transform hover:-translate-y-1 active:scale-95"
            >
              {cat.image_url ? (
                <div className="relative h-20 w-20 overflow-hidden rounded-2xl">
                  <Image src={cat.image_url} alt={cat.name_en} fill className="object-cover" />
                </div>
              ) : (
                <div className="flex h-20 w-20 items-center justify-center rounded-2xl bg-secondary text-4xl">
                  {cat.name_en === "Birthday Cake" ? "🎂"
                    : cat.name_en === "Burger" ? "🍔"
                    : cat.name_en === "Chocolate" ? "🍫"
                    : "🛍️"}
                </div>
              )}
              <div>
                <p className="font-bold text-accent group-hover:text-primary transition-colors">
                  {cat.name_en}
                </p>
                {cat.description_en && (
                  <p className="mt-1 text-xs text-accent-light line-clamp-2">
                    {cat.description_en}
                  </p>
                )}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
