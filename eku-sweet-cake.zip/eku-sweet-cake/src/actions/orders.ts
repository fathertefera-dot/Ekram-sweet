"use server";

import { revalidatePath } from "next/cache";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";
import { checkoutSchema, updateOrderStatusSchema } from "@/lib/validations";
import { sendOrderNotification } from "@/lib/telegram";
import type {
  ActionResult,
  CartItem,
  Order,
  OrderItem,
  DashboardStats,
} from "@/types/database";

// ── Place order (guest checkout — uses service role to bypass RLS) ────────────

interface PlaceOrderInput {
  customerName: string;
  customerPhone: string;
  deliveryAddress: string;
  additionalNote?: string;
  paymentMethod: "cod" | "telebirr" | "cbe_birr";
  items: CartItem[];
}

export async function placeOrder(
  input: PlaceOrderInput
): Promise<ActionResult<{ orderNumber: number }>> {
  // 1. Validate checkout fields
  const parsed = checkoutSchema.safeParse({
    customerName: input.customerName,
    customerPhone: input.customerPhone,
    deliveryAddress: input.deliveryAddress,
    additionalNote: input.additionalNote ?? "",
    paymentMethod: input.paymentMethod,
  });

  if (!parsed.success) {
    return {
      success: false,
      error: parsed.error.errors[0]?.message ?? "Validation failed.",
    };
  }

  if (!input.items.length) {
    return { success: false, error: "Your cart is empty." };
  }

  const subtotal = input.items.reduce(
    (sum, i) => sum + i.unitPrice * i.quantity,
    0
  );
  const total = subtotal; // delivery is always free

  const adminClient = createAdminClient();

  // 2. Insert the order
  const { data: order, error: orderErr } = await adminClient
    .from("orders")
    .insert({
      customer_name: parsed.data.customerName,
      customer_phone: parsed.data.customerPhone,
      delivery_address: parsed.data.deliveryAddress,
      additional_note: parsed.data.additionalNote ?? "",
      payment_method: parsed.data.paymentMethod,
      subtotal,
      total,
      status: "pending",
    })
    .select()
    .single();

  if (orderErr || !order) {
    console.error("[placeOrder] order insert:", orderErr?.message);
    return { success: false, error: "Failed to place order. Please try again." };
  }

  // 3. Insert order items
  const { data: orderItems, error: itemsErr } = await adminClient
    .from("order_items")
    .insert(
      input.items.map((item) => ({
        order_id: order.id,
        product_id: item.productId,
        product_name_en: item.nameEn,
        product_name_am: item.nameAm,
        price_label: item.priceLabel,
        unit_price: item.unitPrice,
        quantity: item.quantity,
        line_total: item.unitPrice * item.quantity,
        cake_message: item.cakeMessage ?? null,
        schedule_date: item.scheduleDate ?? null,
      }))
    )
    .select();

  if (itemsErr) {
    console.error("[placeOrder] items insert:", itemsErr.message);
    // Order exists but items failed — surface error without rolling back
    // (admin can inspect & correct in the dashboard).
    return { success: false, error: "Order created but items failed. Please contact support." };
  }

  // 4. Send Telegram notification (fire-and-forget)
  sendOrderNotification({
    ...order,
    items: (orderItems ?? []) as OrderItem[],
  }).catch(console.error);

  revalidatePath("/admin/orders");
  revalidatePath("/admin/dashboard");

  return { success: true, data: { orderNumber: order.order_number } };
}

// ── Fetch a single order by order_number (for the success page) ──────────────

export async function getOrderByNumber(
  orderNumber: number
): Promise<(Order & { items: OrderItem[] }) | null> {
  const adminClient = createAdminClient();

  const { data: order, error } = await adminClient
    .from("orders")
    .select("*, items:order_items(*)")
    .eq("order_number", orderNumber)
    .single();

  if (error || !order) return null;
  return order as Order & { items: OrderItem[] };
}

// ── Admin: list all orders ────────────────────────────────────────────────────

export async function getOrders(): Promise<(Order & { items: OrderItem[] })[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("orders")
    .select("*, items:order_items(*)")
    .order("created_at", { ascending: false });

  if (error) {
    console.error("[getOrders]", error.message);
    return [];
  }
  return (data ?? []) as (Order & { items: OrderItem[] })[];
}

// ── Admin: update order status ────────────────────────────────────────────────

export async function updateOrderStatus(
  orderId: string,
  status: Order["status"]
): Promise<ActionResult> {
  const parsed = updateOrderStatusSchema.safeParse({ orderId, status });
  if (!parsed.success) {
    return { success: false, error: "Invalid status value." };
  }

  const supabase = await createClient();
  const { error } = await supabase
    .from("orders")
    .update({ status: parsed.data.status })
    .eq("id", parsed.data.orderId);

  if (error) return { success: false, error: error.message };

  revalidatePath("/admin/orders");
  revalidatePath("/admin/dashboard");
  return { success: true, data: undefined };
}

// ── Admin: dashboard stats ────────────────────────────────────────────────────

export async function getDashboardStats(): Promise<DashboardStats> {
  const supabase = await createClient();

  const now = new Date();
  const startOfDay = new Date(now);
  startOfDay.setHours(0, 0, 0, 0);
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  const { data: orders } = await supabase
    .from("orders")
    .select("status, total, created_at");

  const rows = orders ?? [];

  const todaysOrders = rows.filter(
    (o) => new Date(o.created_at) >= startOfDay
  ).length;

  const pendingOrders = rows.filter((o) => o.status === "pending").length;

  const deliveredOrders = rows.filter((o) => o.status === "delivered").length;

  const revenueToday = rows
    .filter(
      (o) =>
        new Date(o.created_at) >= startOfDay &&
        o.status !== "cancelled"
    )
    .reduce((sum, o) => sum + (o.total ?? 0), 0);

  const revenueThisMonth = rows
    .filter(
      (o) =>
        new Date(o.created_at) >= startOfMonth &&
        o.status !== "cancelled"
    )
    .reduce((sum, o) => sum + (o.total ?? 0), 0);

  return {
    todaysOrders,
    pendingOrders,
    deliveredOrders,
    revenueToday,
    revenueThisMonth,
  };
}
