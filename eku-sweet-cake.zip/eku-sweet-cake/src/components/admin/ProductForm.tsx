"use client";

import { useState, useRef } from "react";
import { useRouter } from "next/navigation";
import Image from "next/image";
import { Plus, Trash2, Upload, X } from "lucide-react";
import { createProduct, updateProduct, addProductImageRecord } from "@/actions/products";
import { createClient } from "@/lib/supabase/client";
import type { Category, ProductWithRelations } from "@/types/database";

interface PriceOption {
  id?: string;
  label: string;
  price: number | "";
  sortOrder: number;
}

interface Props {
  categories: Category[];
  product?: ProductWithRelations;
}

export function ProductForm({ categories, product }: Props) {
  const router = useRouter();
  const fileRef = useRef<HTMLInputElement>(null);

  const [form, setForm] = useState({
    categoryId: product?.category_id ?? "",
    nameEn: product?.name_en ?? "",
    nameAm: product?.name_am ?? "",
    descriptionEn: product?.description_en ?? "",
    descriptionAm: product?.description_am ?? "",
    isAvailable: product?.is_available ?? true,
    requireMessage: product?.require_message ?? false,
    requireScheduleDate: product?.require_schedule_date ?? false,
    requireAdvancePayment: product?.require_advance_payment ?? false,
    minimumNoticeDays: product?.minimum_notice_days ?? 0,
    sortOrder: product?.sort_order ?? 0,
  });

  const [prices, setPrices] = useState<PriceOption[]>(
    product?.prices && product.prices.length > 0
      ? product.prices.map((p) => ({ id: p.id, label: p.label, price: p.price, sortOrder: p.sort_order }))
      : [{ label: "", price: "", sortOrder: 0 }]
  );

  const [existingImages, setExistingImages] = useState(product?.images ?? []);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  // ── Price options ────────────────────────────────────────────────────
  function addPrice() {
    setPrices((p) => [...p, { label: "", price: "", sortOrder: p.length }]);
  }
  function removePrice(idx: number) {
    setPrices((p) => p.filter((_, i) => i !== idx));
  }
  function updatePrice(idx: number, field: keyof PriceOption, value: string | number) {
    setPrices((p) => p.map((item, i) => i === idx ? { ...item, [field]: value } : item));
  }

  // ── Image upload ─────────────────────────────────────────────────────
  async function handleImageUpload(e: React.ChangeEvent<HTMLInputElement>) {
    const files = Array.from(e.target.files ?? []);
    if (!files.length) return;

    if (existingImages.length + files.length > 10) {
      setError("Maximum 10 photos allowed per product.");
      return;
    }

    setUploading(true);
    setError("");
    const supabase = createClient();

    for (const file of files) {
      const ext = file.name.split(".").pop();
      const path = `${Date.now()}-${Math.random().toString(36).slice(2)}.${ext}`;
      const { error: uploadErr } = await supabase.storage
        .from("products")
        .upload(path, file, { contentType: file.type, upsert: false });

      if (uploadErr) { setError(uploadErr.message); continue; }

      const { data: urlData } = supabase.storage.from("products").getPublicUrl(path);

      if (product?.id) {
        // Existing product — save immediately
        await addProductImageRecord(product.id, urlData.publicUrl, existingImages.length);
        setExistingImages((imgs) => [
          ...imgs,
          { id: Date.now().toString(), product_id: product.id, url: urlData.publicUrl, sort_order: imgs.length, created_at: new Date().toISOString() },
        ]);
      } else {
        // New product — collect urls to attach after product is created
        setExistingImages((imgs) => [
          ...imgs,
          { id: Date.now().toString(), product_id: "", url: urlData.publicUrl, sort_order: imgs.length, created_at: new Date().toISOString() },
        ]);
      }
    }
    setUploading(false);
    if (fileRef.current) fileRef.current.value = "";
  }

  // ── Save ─────────────────────────────────────────────────────────────
  async function handleSave() {
    setError("");
    setSaving(true);

    const input = {
      ...form,
      prices: prices.map((p, idx) => ({
        id: p.id,
        label: p.label,
        price: Number(p.price),
        sortOrder: idx,
      })),
    };

    const result = product
      ? await updateProduct(product.id, input)
      : await createProduct(input);

    if (!result.success) {
      setError(result.error);
      setSaving(false);
      return;
    }

    // Attach images for newly created product
    if (!product && result.success) {
      const newId = (result.data as { id: string }).id;
      for (let i = 0; i < existingImages.length; i++) {
        await addProductImageRecord(newId, existingImages[i].url, i);
      }
    }

    setSaving(false);
    router.push("/admin/products");
    router.refresh();
  }

  const Toggle = ({ label, field }: { label: string; field: keyof typeof form }) => (
    <label className="flex items-center gap-3 cursor-pointer">
      <div
        onClick={() => setForm((f) => ({ ...f, [field]: !f[field as keyof typeof f] }))}
        className={`relative h-6 w-11 rounded-full transition-colors ${form[field as keyof typeof form] ? "bg-primary" : "bg-accent-200"}`}
      >
        <div className={`absolute top-0.5 h-5 w-5 rounded-full bg-white shadow transition-transform ${form[field as keyof typeof form] ? "translate-x-5" : "translate-x-0.5"}`} />
      </div>
      <span className="text-sm font-medium text-accent">{label}</span>
    </label>
  );

  return (
    <div className="flex flex-col gap-5 max-w-2xl">
      {/* Basic info */}
      <div className="card p-6 flex flex-col gap-4">
        <h2 className="font-bold text-accent">Basic Information</h2>

        <div>
          <label className="field-label">Category</label>
          <select
            className="field-input"
            value={form.categoryId}
            onChange={(e) => setForm((f) => ({ ...f, categoryId: e.target.value }))}
          >
            <option value="">— Select category —</option>
            {categories.map((cat) => (
              <option key={cat.id} value={cat.id}>{cat.name_en}</option>
            ))}
          </select>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="field-label">Name (English)</label>
            <input className="field-input" value={form.nameEn}
              onChange={(e) => setForm((f) => ({ ...f, nameEn: e.target.value }))}
              placeholder="Classic Birthday Cake" />
          </div>
          <div>
            <label className="field-label">Name (አማርኛ)</label>
            <input className="field-input" value={form.nameAm}
              onChange={(e) => setForm((f) => ({ ...f, nameAm: e.target.value }))}
              placeholder="ክላሲክ የልደት ኬክ" />
          </div>
        </div>

        <div className="grid gap-4 sm:grid-cols-2">
          <div>
            <label className="field-label">Description (English)</label>
            <textarea rows={3} className="field-input resize-none" value={form.descriptionEn}
              onChange={(e) => setForm((f) => ({ ...f, descriptionEn: e.target.value }))} />
          </div>
          <div>
            <label className="field-label">Description (አማርኛ)</label>
            <textarea rows={3} className="field-input resize-none" value={form.descriptionAm}
              onChange={(e) => setForm((f) => ({ ...f, descriptionAm: e.target.value }))} />
          </div>
        </div>

        <div className="flex items-center gap-6">
          <Toggle label="Available" field="isAvailable" />
          <div>
            <label className="field-label">Sort Order</label>
            <input type="number" min={0} className="field-input w-24" value={form.sortOrder}
              onChange={(e) => setForm((f) => ({ ...f, sortOrder: Number(e.target.value) }))} />
          </div>
        </div>
      </div>

      {/* Price options */}
      <div className="card p-6 flex flex-col gap-4">
        <h2 className="font-bold text-accent">Price Options</h2>
        {prices.map((price, idx) => (
          <div key={idx} className="flex items-end gap-3">
            <div className="flex-1">
              <label className="field-label">Label (e.g. 1 kg)</label>
              <input className="field-input" value={price.label}
                onChange={(e) => updatePrice(idx, "label", e.target.value)}
                placeholder="1 kg" />
            </div>
            <div className="flex-1">
              <label className="field-label">Price (ETB)</label>
              <input type="number" min={1} className="field-input" value={price.price}
                onChange={(e) => updatePrice(idx, "price", e.target.value)}
                placeholder="1000" />
            </div>
            {prices.length > 1 && (
              <button onClick={() => removePrice(idx)}
                className="mb-0.5 flex h-10 w-10 items-center justify-center rounded-xl text-red-400 hover:bg-red-50 hover:text-red-600 transition">
                <Trash2 size={16} />
              </button>
            )}
          </div>
        ))}
        <button onClick={addPrice} className="btn-outline self-start text-sm">
          <Plus size={14} /> Add Price Option
        </button>
      </div>

      {/* Product rules */}
      <div className="card p-6 flex flex-col gap-4">
        <h2 className="font-bold text-accent">Product Rules</h2>
        <p className="text-xs text-accent-light">Configure what this product requires from customers at checkout.</p>
        <div className="flex flex-col gap-4">
          <Toggle label="Require Cake Message" field="requireMessage" />
          <Toggle label="Require Delivery Date" field="requireScheduleDate" />
          <Toggle label="Require Advance Payment (disables Cash on Delivery)" field="requireAdvancePayment" />
          <div>
            <label className="field-label">Minimum Notice Days</label>
            <input type="number" min={0} max={60} className="field-input w-24" value={form.minimumNoticeDays}
              onChange={(e) => setForm((f) => ({ ...f, minimumNoticeDays: Number(e.target.value) }))} />
            <p className="mt-1 text-xs text-accent-light">Days in advance the customer must order. 0 = same day.</p>
          </div>
        </div>
      </div>

      {/* Photos */}
      <div className="card p-6 flex flex-col gap-4">
        <h2 className="font-bold text-accent">Photos <span className="text-xs font-normal text-accent-light">(max 10)</span></h2>

        <div className="grid grid-cols-3 gap-3 sm:grid-cols-5">
          {existingImages.map((img) => (
            <div key={img.id} className="relative aspect-square rounded-2xl overflow-hidden bg-secondary group">
              <Image src={img.url} alt="" fill className="object-cover" />
              <button
                onClick={() => setExistingImages((imgs) => imgs.filter((i) => i.id !== img.id))}
                className="absolute right-1 top-1 flex h-6 w-6 items-center justify-center rounded-full bg-white/90 text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
              >
                <X size={12} />
              </button>
            </div>
          ))}

          {existingImages.length < 10 && (
            <button
              onClick={() => fileRef.current?.click()}
              className="aspect-square rounded-2xl border-2 border-dashed border-accent-200 flex flex-col items-center justify-center gap-1 hover:border-primary/50 hover:bg-secondary transition text-accent-light"
            >
              {uploading ? <span className="text-xs animate-pulse">Uploading…</span> : <><Upload size={18} /><span className="text-xs">Upload</span></>}
            </button>
          )}
        </div>

        <input ref={fileRef} type="file" multiple accept="image/*" className="hidden" onChange={handleImageUpload} />
      </div>

      {error && <div className="rounded-2xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-600">{error}</div>}

      <div className="flex gap-3">
        <button onClick={handleSave} disabled={saving || uploading} className="btn-primary">
          {saving ? "Saving…" : product ? "Update Product" : "Create Product"}
        </button>
        <button onClick={() => router.push("/admin/products")} className="btn-outline">Cancel</button>
      </div>
    </div>
  );
}
