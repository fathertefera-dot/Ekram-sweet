import type { Locale } from "@/types/database";

export const translations = {
  en: {
    // ── Site wide ──────────────────────────────────────────────────────────
    siteName: "Eku Sweet Cake",
    tagline: "Cakes, Chocolate & Burgers — Made with Love",
    loading: "Loading…",
    error: "Something went wrong. Please try again.",
    save: "Save",
    cancel: "Cancel",
    delete: "Delete",
    edit: "Edit",
    add: "Add",
    back: "Back",
    confirm: "Confirm",
    close: "Close",
    yes: "Yes",
    no: "No",
    required: "Required",
    optional: "Optional",
    search: "Search",
    noResults: "No results found.",
    tryAgain: "Try again",
    viewAll: "View All",
    outOfStock: "Out of Stock",
    available: "Available",
    free: "Free",
    delivery: "Delivery",
    total: "Total",
    subtotal: "Subtotal",

    // ── Navigation ─────────────────────────────────────────────────────────
    home: "Home",
    categories: "Categories",
    cart: "Cart",
    checkout: "Checkout",

    // ── Home page ─────────────────────────────────────────────────────────
    heroTitle: "Sweet Moments,\nDelivered Fresh",
    heroSubtitle:
      "Custom birthday cakes, handcrafted chocolates, and juicy burgers — all made to order in Addis Ababa.",
    orderNow: "Order Now",
    exploreMenu: "Explore Menu",
    featuredProducts: "Featured Products",
    shopByCategory: "Shop by Category",
    whyChooseUs: "Why Choose Eku?",
    freshIngredients: "Fresh Ingredients",
    freshIngredientsDesc: "We use only the finest local and imported ingredients.",
    freeDelivery: "Free Delivery",
    freeDeliveryDesc: "Free delivery on every order, no minimum required.",
    madeToOrder: "Made to Order",
    madeToOrderDesc: "Everything is prepared fresh when you place your order.",

    // ── Product ───────────────────────────────────────────────────────────
    addToCart: "Add to Cart",
    selectSize: "Select Size",
    selectPrice: "Select Price Option",
    cakeMessage: "Cake Message",
    cakeMessagePlaceholder: 'e.g. "Happy Birthday Hana! 🎂"',
    deliveryDate: "Delivery Date",
    deliveryDateHelp: (days: number) =>
      `Minimum ${days} day${days !== 1 ? "s" : ""} advance notice required.`,
    productDetails: "Product Details",
    relatedProducts: "You May Also Like",
    noProductsInCategory: "No products in this category yet.",

    // ── Cart ──────────────────────────────────────────────────────────────
    myCart: "My Cart",
    cartEmpty: "Your cart is empty",
    cartEmptyHint: "Browse our menu and add some delicious items!",
    browseMenu: "Browse Menu",
    remove: "Remove",
    quantity: "Quantity",
    proceedToCheckout: "Proceed to Checkout",
    freeDeliveryNote: "🚚 Free delivery on all orders",

    // ── Checkout ──────────────────────────────────────────────────────────
    customerDetails: "Your Details",
    fullName: "Full Name",
    fullNamePlaceholder: "Abebe Kebede",
    phone: "Phone Number",
    phonePlaceholder: "09xxxxxxxx",
    deliveryAddress: "Delivery Address",
    deliveryAddressPlaceholder: "e.g. Bole, Addis Ababa — near Edna Mall",
    additionalNote: "Additional Note",
    additionalNotePlaceholder: "Any special instructions for delivery or preparation?",
    paymentMethod: "Payment Method",
    cashOnDelivery: "Cash on Delivery",
    telebirr: "Telebirr",
    cbeBirr: "CBE Birr",
    payTo: "Pay to",
    placeOrder: "Place Order",
    orderSummary: "Order Summary",
    advancePaymentRequired:
      "⚠️ This product requires advance payment (Telebirr or CBE Birr).",

    // ── Order success ─────────────────────────────────────────────────────
    orderSuccess: "Order Placed!",
    orderSuccessMessage:
      "Thank you for your order. We will contact you shortly to confirm.",
    orderNumber: "Order Number",
    continueShopping: "Continue Shopping",

    // ── Admin ─────────────────────────────────────────────────────────────
    adminPanel: "Admin Panel",
    dashboard: "Dashboard",
    products: "Products",
    orders: "Orders",
    settings: "Settings",
    signIn: "Sign In",
    signOut: "Sign Out",
    email: "Email",
    password: "Password",
    todaysOrders: "Today's Orders",
    pendingOrders: "Pending Orders",
    deliveredOrders: "Delivered Orders",
    revenueToday: "Revenue Today",
    revenueThisMonth: "Revenue This Month",
    newCategory: "New Category",
    newProduct: "New Product",
    updateStatus: "Update Status",
    paymentSettings: "Payment Settings",
    telebirrNumber: "Telebirr Number",
    cbeNumber: "CBE Birr Number",
    enable: "Enable",
    disable: "Disable",
    enabled: "Enabled",
    disabled: "Disabled",
    noOrders: "No orders yet.",
    photos: "Photos",
    uploadPhotos: "Upload Photos",
    maxPhotos: "Maximum 10 photos allowed.",
    productRules: "Product Rules",
    requireMessage: "Require Cake Message",
    requireScheduleDate: "Require Delivery Date",
    requireAdvancePayment: "Require Advance Payment",
    minimumNoticeDays: "Minimum Notice Days",
    priceOptions: "Price Options",
    addPriceOption: "Add Price Option",
    label: "Label",
    price: "Price (ETB)",

    // ── Order statuses ────────────────────────────────────────────────────
    status_pending: "Pending",
    status_confirmed: "Confirmed",
    status_preparing: "Preparing",
    status_out_for_delivery: "Out for Delivery",
    status_delivered: "Delivered",
    status_cancelled: "Cancelled",

    // ── Validation ────────────────────────────────────────────────────────
    validationRequired: "This field is required.",
    validationPhone: "Please enter a valid phone number.",
    validationDate: "Please select a valid delivery date.",
    validationPriceOption: "Please select a price option.",
    validationCakeMessage: "Please enter the cake message.",
  },

  am: {
    // ── Site wide ──────────────────────────────────────────────────────────
    siteName: "Eku Sweet Cake",
    tagline: "ኬኮች፣ ቸኮሌቶች እና በርገሮች — በፍቅር የተሰሩ",
    loading: "በመጫን ላይ…",
    error: "የሆነ ችግር ተፈጥሯል። እባክዎ እንደገና ይሞክሩ።",
    save: "አስቀምጥ",
    cancel: "ሰርዝ",
    delete: "አጥፋ",
    edit: "አርም",
    add: "ጨምር",
    back: "ተመለስ",
    confirm: "አረጋግጥ",
    close: "ዝጋ",
    yes: "አዎ",
    no: "አይ",
    required: "አስፈላጊ",
    optional: "አማራጭ",
    search: "ፈልግ",
    noResults: "ምንም ውጤት አልተገኘም።",
    tryAgain: "እንደገና ሞክር",
    viewAll: "ሁሉንም እይ",
    outOfStock: "ክምችት አልቋል",
    available: "ይገኛል",
    free: "ነፃ",
    delivery: "ዴሊቨሪ",
    total: "ጠቅላላ",
    subtotal: "ድምር",

    // ── Navigation ─────────────────────────────────────────────────────────
    home: "መነሻ",
    categories: "ምድቦች",
    cart: "ቅርጫት",
    checkout: "ክፍያ",

    // ── Home page ─────────────────────────────────────────────────────────
    heroTitle: "ጣፋጭ ቅጆች፣\nትኩስ ዴሊቨሪ",
    heroSubtitle:
      "የልደት ኬኮች፣ የቸኮሌት ስጦታዎች እና ጣፋጭ በርገሮች — ሁሉም በአዲስ አበባ ትዕዛዝ ሲሰጥ ይዘጋጃሉ።",
    orderNow: "አሁን ዘምት",
    exploreMenu: "ምናሌ ዳስስ",
    featuredProducts: "ተወዳጅ ምርቶች",
    shopByCategory: "በምድብ ግዛ",
    whyChooseUs: "ለምን Eku?",
    freshIngredients: "ትኩስ ግብዓቶች",
    freshIngredientsDesc: "የምርጥ አካባቢያዊ እና ዓለም አቀፍ ግብዓቶችን ብቻ እንጠቀማለን።",
    freeDelivery: "ነፃ ዴሊቨሪ",
    freeDeliveryDesc: "ለሁሉም ትዕዛዞች ነፃ ዴሊቨሪ፣ ምንም አነስተኛ ዋጋ የለም።",
    madeToOrder: "ትዕዛዝ ሲሰጥ ይዘጋጃል",
    madeToOrderDesc: "ትዕዛዝ ሲሰጡ ሁሉም ነገር ትኩስ ሆኖ ይዘጋጃል።",

    // ── Product ───────────────────────────────────────────────────────────
    addToCart: "ወደ ቅርጫት ጨምር",
    selectSize: "መጠን ምረጥ",
    selectPrice: "የዋጋ አማራጭ ምረጥ",
    cakeMessage: "የኬክ መልዕክት",
    cakeMessagePlaceholder: 'ለምሳሌ "መልካም ልደት ሃና! 🎂"',
    deliveryDate: "የዴሊቨሪ ቀን",
    deliveryDateHelp: (days: number) =>
      `ቢያንስ ${days} ቀን አስቀድሞ ማዘዝ ያስፈልጋል።`,
    productDetails: "የምርት ዝርዝር",
    relatedProducts: "ሌሎች ምርቶች",
    noProductsInCategory: "በዚህ ምድብ ምንም ምርቶች አልተጨመሩም።",

    // ── Cart ──────────────────────────────────────────────────────────────
    myCart: "ቅርጫቴ",
    cartEmpty: "ቅርጫትዎ ባዶ ነው",
    cartEmptyHint: "ምናሌ ዳስሰው ጣፋጭ ምርቶችን ይጨምሩ!",
    browseMenu: "ምናሌ ዳስስ",
    remove: "አስወግድ",
    quantity: "ብዛት",
    proceedToCheckout: "ወደ ክፍያ ቀጥል",
    freeDeliveryNote: "🚚 ለሁሉም ትዕዛዞች ነፃ ዴሊቨሪ",

    // ── Checkout ──────────────────────────────────────────────────────────
    customerDetails: "የእርስዎ ዝርዝር",
    fullName: "ሙሉ ስም",
    fullNamePlaceholder: "አበበ ከበደ",
    phone: "ስልክ ቁጥር",
    phonePlaceholder: "09xxxxxxxx",
    deliveryAddress: "የዴሊቨሪ አድራሻ",
    deliveryAddressPlaceholder: "ለምሳሌ ቦሌ፣ አዲስ አበባ — ኤድና ሞል አቅራቢያ",
    additionalNote: "ተጨማሪ ማስታወሻ",
    additionalNotePlaceholder: "ለዴሊቨሪ ወይም ዝግጅት ልዩ መመሪያ አለዎት?",
    paymentMethod: "የክፍያ ዘዴ",
    cashOnDelivery: "ሲደርስ ይከፈላል",
    telebirr: "Telebirr",
    cbeBirr: "CBE Birr",
    payTo: "ለ",
    placeOrder: "ትዕዛዝ ስጥ",
    orderSummary: "የትዕዛዝ ማጠቃለያ",
    advancePaymentRequired:
      "⚠️ ይህ ምርት አስቀድሞ ክፍያ ይጠይቃል (Telebirr ወይም CBE Birr)።",

    // ── Order success ─────────────────────────────────────────────────────
    orderSuccess: "ትዕዛዝ ተቀብሏል!",
    orderSuccessMessage:
      "ስለ ትዕዛዝዎ እናመሰግናለን። ለማረጋገጥ በቅርቡ እናገኝዎታለን።",
    orderNumber: "የትዕዛዝ ቁጥር",
    continueShopping: "ግዢ ቀጥል",

    // ── Admin ─────────────────────────────────────────────────────────────
    adminPanel: "አስተዳዳሪ ፓናል",
    dashboard: "ዳሽቦርድ",
    products: "ምርቶች",
    orders: "ትዕዛዞች",
    settings: "ቅንብሮች",
    signIn: "ግባ",
    signOut: "ውጣ",
    email: "ኢሜይል",
    password: "የሚስጥር ቁጥር",
    todaysOrders: "የዛሬ ትዕዛዞች",
    pendingOrders: "በጥበቃ ላይ",
    deliveredOrders: "የደረሱ",
    revenueToday: "የዛሬ ገቢ",
    revenueThisMonth: "የዚህ ወር ገቢ",
    newCategory: "አዲስ ምድብ",
    newProduct: "አዲስ ምርት",
    updateStatus: "ሁኔታ አዘምን",
    paymentSettings: "የክፍያ ቅንብሮች",
    telebirrNumber: "Telebirr ቁጥር",
    cbeNumber: "CBE Birr ቁጥር",
    enable: "አንቃ",
    disable: "አሰናክል",
    enabled: "ነቅቷል",
    disabled: "ተሰናክሏል",
    noOrders: "ምንም ትዕዛዞች የሉም።",
    photos: "ፎቶዎች",
    uploadPhotos: "ፎቶ ስቀል",
    maxPhotos: "ቢበዛ 10 ፎቶ ይፈቀዳል።",
    productRules: "የምርት ደንቦች",
    requireMessage: "የኬክ መልዕክት ያስፈልጋል",
    requireScheduleDate: "የዴሊቨሪ ቀን ያስፈልጋል",
    requireAdvancePayment: "አስቀድሞ ክፍያ ያስፈልጋል",
    minimumNoticeDays: "አነስተኛ የማስጠንቀቂያ ቀናት",
    priceOptions: "የዋጋ አማራጮች",
    addPriceOption: "የዋጋ አማራጭ ጨምር",
    label: "መለያ",
    price: "ዋጋ (ብር)",

    // ── Order statuses ────────────────────────────────────────────────────
    status_pending: "በጥበቃ ላይ",
    status_confirmed: "ተረጋግጧል",
    status_preparing: "በዝግጅት ላይ",
    status_out_for_delivery: "ሲደርስ ሲደርስ",
    status_delivered: "ደርሷል",
    status_cancelled: "ተሰርዟል",

    // ── Validation ────────────────────────────────────────────────────────
    validationRequired: "ይህ መስክ አስፈላጊ ነው።",
    validationPhone: "ትክክለኛ ስልክ ቁጥር ያስገቡ።",
    validationDate: "ትክክለኛ የዴሊቨሪ ቀን ምረጥ።",
    validationPriceOption: "የዋጋ አማራጭ ምረጥ።",
    validationCakeMessage: "የኬክ መልዕክት ያስገቡ።",
  },
} as const;

export type TranslationKey = keyof typeof translations.en;
export type Translations = typeof translations.en;

export function getTranslations(locale: Locale): Translations {
  return translations[locale] as Translations;
}

/** Resolve a bilingual name (name_en / name_am) based on current locale. */
export function localeName(
  obj: { name_en: string; name_am: string },
  locale: Locale
): string {
  return locale === "am" ? obj.name_am : obj.name_en;
}

/** Resolve a bilingual description. */
export function localeDescription(
  obj: { description_en: string; description_am: string },
  locale: Locale
): string {
  return locale === "am" ? obj.description_am : obj.description_en;
}
