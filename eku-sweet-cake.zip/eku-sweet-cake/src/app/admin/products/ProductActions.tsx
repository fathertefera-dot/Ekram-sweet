"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Trash2 } from "lucide-react";
import { deleteProduct } from "@/actions/products";

export function AdminProductActions({ productId }: { productId: string }) {
  const router = useRouter();
  const [confirm, setConfirm] = useState(false);
  const [loading, setLoading] = useState(false);

  async function handleDelete() {
    setLoading(true);
    const result = await deleteProduct(productId);
    setLoading(false);
    if (!result.success) { alert(result.error); return; }
    setConfirm(false);
    router.refresh();
  }

  return (
    <>
      <button
        onClick={() => setConfirm(true)}
        className="flex h-8 w-8 items-center justify-center rounded-xl text-accent-light hover:bg-red-50 hover:text-red-500 transition"
      >
        <Trash2 size={14} />
      </button>

      {confirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-accent/40 backdrop-blur-sm px-4">
          <div className="card w-full max-w-sm p-6">
            <h3 className="mb-2 font-bold text-accent">Delete Product?</h3>
            <p className="mb-5 text-sm text-accent-light">
              This will permanently delete the product and its images.
            </p>
            <div className="flex gap-3">
              <button
                onClick={handleDelete}
                disabled={loading}
                className="btn-primary !bg-red-500"
              >
                {loading ? "Deleting…" : "Delete"}
              </button>
              <button onClick={() => setConfirm(false)} className="btn-outline">
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
