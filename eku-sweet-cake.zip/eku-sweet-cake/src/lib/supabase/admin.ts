import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/types/database";

/**
 * Returns a Supabase client authenticated with the service-role key.
 * This client bypasses Row Level Security — use it ONLY inside Server
 * Actions or Route Handlers where:
 *   • Guest-checkout order insertion is needed (no auth session), OR
 *   • An admin needs to perform bulk writes without per-row RLS checks.
 *
 * Never import this file from any client-side module.
 */
export function createAdminClient() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

  if (!url || !serviceKey) {
    throw new Error(
      "Missing NEXT_PUBLIC_SUPABASE_URL or SUPABASE_SERVICE_ROLE_KEY environment variables."
    );
  }

  return createClient<Database>(url, serviceKey, {
    auth: {
      autoRefreshToken: false,
      persistSession: false,
    },
  });
}
