import { getCategories } from "@/actions/categories";
import { ProductForm } from "@/components/admin/ProductForm";

export default async function NewProductPage() {
  const categories = await getCategories();
  return (
    <div className="p-6">
      <h1 className="mb-6 text-2xl font-bold text-accent">New Product</h1>
      <ProductForm categories={categories} />
    </div>
  );
}
