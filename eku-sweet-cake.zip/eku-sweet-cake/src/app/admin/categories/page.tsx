"use client";

import { useState, useEffect, useCallback } from "react";
import { Plus, Trash2, Pencil, GripVertical } from "lucide-react";
import {
  getCategories,
  createCategory,
  updateCategory,
  deleteCategory,
} from "@/actions/categories";
import { slugify } from "@/lib/utils";
import type { Category } from "@/types/database";

type Mode = "list" | "create" | "edit";

const EMPTY_FORM = {
  nameEn: "",
  nameAm: "",
  slug: "",
  descriptionEn: "",
  descriptionAm: "",
  sortOrder: 0,
  isActive: true,
};

export default function AdminCategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [mode, setMode] = useState<Mode>("list");
  const [editing, setEditing] = useState<Category | null>(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const load = useCallback(async () => {
    const data = await getCategories();
    setCategories(data);
  }, []);

  useEffect(() => { load(); }, [load]);

  function openCreate() {
    setForm(EMPTY_FORM);
    setEditing(null);
    setError("");
    setMode("create");
  }

  function openEdit(cat: Category) {
    setForm({
      nameEn: cat.name_en,
      nameAm: cat.name_am,
      slug: cat.slug,
      descriptionEn: cat.description_en,
      descriptionAm: cat.description_am,
      sortOrder: cat.sort_order,
      isActive: cat.is_active,
    });
    setEditing(cat);
    setError("");
    setMode("edit");
  }

  function handleNameEnChange(val: string) {
    setForm((f) => ({
      ...f,
      nameEn: val,
      slug: editing ? f.slug : slugify(val),
    }));
  }

  async function handleSave() {
    setError("");
    setLoading(true);
    const result = editing
      ? await updateCategory(editing.id, form)
      : await createCategory(form);
    setLoading(false);

    if (!result.success) { setError(result.error); return; }
    await load();
    setMode("list");
  }

  async function handleDelete(id: string) {
    const result = await deleteCategory(id);
    if (!result.success) { alert(result.error); return; }
    setDeleteId(null);
    await load();
  }

  if (mode !== "list") {
    return (
      <div className="p-6 max-w-xl">
        <button onClick={() => setMode("list")} className="mb-5 text-sm text-accent-light hover:text-accent flex items-center gap-1">
          ← Back to Categories
        </button>
        <h1 className="mb-6 text-xl font-bold text-accent">
          {mode === "create" ? "New Category" : "Edit Category"}
        </h1>

        <div className="card p-6 flex flex-col gap-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="field-label">Name (English)</label>
              <input className="field-input" value={form.nameEn}
                onChange={(e) => handleNameEnChange(e.target.value)} placeholder="Birthday Cake" />
            </div>
            <div>
              <label className="field-label">Name (አማርኛ)</label>
              <input className="field-input" value={form.nameAm}
                onChange={(e) => setForm((f) => ({ ...f, nameAm: e.target.value }))} placeholder="የልደት ኬክ" />
            </div>
          </div>

          <div>
            <label className="field-label">Slug</label>
            <input className="field-input font-mono text-xs" value={form.slug}
              onChange={(e) => setForm((f) => ({ ...f, slug: slugify(e.target.value) }))} placeholder="birthday-cake" />
            <p className="mt-1 text-xs text-accent-light">URL-safe identifier, e.g. birthday-cake</p>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="field-label">Description (English)</label>
              <textarea rows={2} className="field-input resize-none" value={form.descriptionEn}
                onChange={(e) => setForm((f) => ({ ...f, descriptionEn: e.target.value }))} />
            </div>
            <div>
              <label className="field-label">Description (አማርኛ)</label>
              <textarea rows={2} className="field-input resize-none" value={form.descriptionAm}
                onChange={(e) => setForm((f) => ({ ...f, descriptionAm: e.target.value }))} />
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <div>
              <label className="field-label">Sort Order</label>
              <input type="number" min={0} className="field-input" value={form.sortOrder}
                onChange={(e) => setForm((f) => ({ ...f, sortOrder: Number(e.target.value) }))} />
            </div>
            <div className="flex items-center gap-3 pt-6">
              <input type="checkbox" id="isActive" checked={form.isActive}
                onChange={(e) => setForm((f) => ({ ...f, isActive: e.target.checked }))}
                className="h-4 w-4 accent-primary" />
              <label htmlFor="isActive" className="text-sm font-medium text-accent">Active</label>
            </div>
          </div>

          {error && <p className="rounded-xl bg-red-50 border border-red-200 px-4 py-2 text-sm text-red-600">{error}</p>}

          <div className="flex gap-3">
            <button onClick={handleSave} disabled={loading} className="btn-primary">
              {loading ? "Saving…" : "Save Category"}
            </button>
            <button onClick={() => setMode("list")} className="btn-outline">Cancel</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="mb-6 flex items-center justify-between">
        <h1 className="text-2xl font-bold text-accent">Categories</h1>
        <button onClick={openCreate} className="btn-primary">
          <Plus size={16} /> New Category
        </button>
      </div>

      {categories.length === 0 ? (
        <div className="card flex flex-col items-center justify-center py-16 text-center">
          <span className="mb-3 text-4xl">🗂️</span>
          <p className="text-accent-light text-sm">No categories yet.</p>
          <button onClick={openCreate} className="mt-4 btn-primary">Create First Category</button>
        </div>
      ) : (
        <div className="card overflow-hidden">
          <table className="w-full text-sm">
            <thead className="border-b border-accent-200 bg-accent-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-accent-light uppercase tracking-wider">Name</th>
                <th className="hidden sm:table-cell px-4 py-3 text-left text-xs font-semibold text-accent-light uppercase tracking-wider">Slug</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-accent-light uppercase tracking-wider">Status</th>
                <th className="px-4 py-3 text-right text-xs font-semibold text-accent-light uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-accent-200">
              {categories.map((cat) => (
                <tr key={cat.id} className="hover:bg-accent-50 transition-colors">
                  <td className="px-4 py-3 font-medium text-accent">{cat.name_en}
                    <span className="ml-2 text-xs text-accent-light">{cat.name_am}</span>
                  </td>
                  <td className="hidden sm:table-cell px-4 py-3 font-mono text-xs text-accent-light">{cat.slug}</td>
                  <td className="px-4 py-3">
                    <span className={`badge ${cat.is_active ? "bg-green-100 text-green-700" : "bg-accent-100 text-accent-light"}`}>
                      {cat.is_active ? "Active" : "Hidden"}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-2">
                      <button onClick={() => openEdit(cat)}
                        className="flex h-8 w-8 items-center justify-center rounded-xl text-accent-light hover:bg-secondary hover:text-accent transition">
                        <Pencil size={14} />
                      </button>
                      <button onClick={() => setDeleteId(cat.id)}
                        className="flex h-8 w-8 items-center justify-center rounded-xl text-accent-light hover:bg-red-50 hover:text-red-500 transition">
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Delete confirm */}
      {deleteId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-accent/40 backdrop-blur-sm px-4">
          <div className="card w-full max-w-sm p-6">
            <h3 className="mb-2 font-bold text-accent">Delete Category?</h3>
            <p className="mb-5 text-sm text-accent-light">
              This action cannot be undone. Products in this category must be removed first.
            </p>
            <div className="flex gap-3">
              <button onClick={() => handleDelete(deleteId)}
                className="btn-primary !bg-red-500">Delete</button>
              <button onClick={() => setDeleteId(null)} className="btn-outline">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
