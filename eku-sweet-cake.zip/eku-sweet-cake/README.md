# Eku Sweet Cake 🎂

A modern, production-ready **PWA** for cake, chocolate and burger ordering.  
Built with **Next.js 15 (App Router) · TypeScript · Tailwind CSS · Supabase · PostgreSQL**.

---

## Features

| Area | Highlights |
|---|---|
| **Storefront** | Home, Categories, Product Detail, Cart, Checkout, Order Success |
| **Language** | English / አማርኛ — switch any time, all products bilingual |
| **Cart** | Persisted across sessions (Zustand + localStorage) |
| **Guest Checkout** | No registration needed, full validation with Zod |
| **Product Rules** | Per-product: require message, delivery date, advance payment — all admin-configurable |
| **Payment Methods** | Cash on Delivery, Telebirr, CBE Birr — toggled in admin |
| **Admin Panel** | Dashboard, Categories, Products, Orders, Settings |
| **Order Notifications** | Telegram bot message on every new order |
| **PWA** | Installable on Android & iOS, offline fallback, manifest + service worker |
| **Security** | Supabase RLS on all tables, service-role key server-side only, middleware auth guard |

---

## Tech Stack

- **Next.js 15** (App Router, Server Actions, Server Components)
- **TypeScript** — fully typed, path aliases via `@/*`
- **Tailwind CSS** — mobile-first, brand design tokens
- **Supabase** — PostgreSQL, Auth, Storage, Row Level Security
- **Zustand** — client-side cart state with persistence
- **Zod** — input validation on all Server Actions

---

## Project Structure

```
eku-sweet-cake/
├── public/
│   ├── icons/            # PWA icons (replace with real PNGs for production)
│   ├── manifest.json     # Web App Manifest
│   ├── sw.js             # Service Worker
│   └── offline.html      # Offline fallback
│
├── scripts/
│   └── generate-icons.js # Helper to generate placeholder icons
│
├── src/
│   ├── actions/          # Next.js Server Actions
│   │   ├── categories.ts
│   │   ├── orders.ts
│   │   ├── products.ts
│   │   └── settings.ts
│   │
│   ├── app/
│   │   ├── (storefront)/ # Public storefront routes
│   │   │   ├── page.tsx              # Home
│   │   │   ├── categories/           # Category listing + [slug]
│   │   │   ├── product/[id]/         # Product detail
│   │   │   ├── cart/                 # Shopping cart
│   │   │   ├── checkout/             # Guest checkout
│   │   │   └── order-success/[n]/    # Order confirmation
│   │   │
│   │   ├── admin/        # Protected admin routes
│   │   │   ├── login/
│   │   │   ├── dashboard/
│   │   │   ├── categories/
│   │   │   ├── products/
│   │   │   ├── orders/
│   │   │   └── settings/
│   │   │
│   │   ├── globals.css
│   │   └── layout.tsx
│   │
│   ├── components/
│   │   ├── admin/        # ProductForm
│   │   ├── layout/       # Header, BottomNav
│   │   ├── product/      # ProductClient (image gallery, add to cart)
│   │   └── providers/    # CartProvider (hydration guard)
│   │
│   ├── lib/
│   │   ├── supabase/     # client.ts | server.ts | admin.ts
│   │   ├── i18n/         # translations.ts (EN + AM)
│   │   ├── telegram.ts   # Order notification helper
│   │   ├── utils.ts      # cn, formatCurrency, slugify …
│   │   └── validations.ts # Zod schemas
│   │
│   ├── middleware.ts      # Admin route protection
│   ├── store/cart.ts      # Zustand cart store
│   └── types/database.ts  # Full TypeScript DB types
│
└── supabase/
    └── migrations/
        ├── 0001_initial_schema.sql
        ├── 0002_rls_policies.sql
        └── 0003_seed_data.sql
```

---

## Getting Started

### 1. Prerequisites

- Node.js 18.18+ and npm
- A free [Supabase](https://supabase.com) account

### 2. Clone and install

```bash
git clone https://github.com/your-org/eku-sweet-cake.git
cd eku-sweet-cake
npm install
```

### 3. Create Supabase project

1. Go to [supabase.com/dashboard](https://supabase.com/dashboard) → **New project**
2. Note down:
   - **Project URL** (Settings → API → Project URL)
   - **anon public key** (Settings → API → Project API keys)
   - **service_role key** (Settings → API → Project API keys — keep secret!)

### 4. Run database migrations

In the Supabase Dashboard → **SQL Editor**, paste and run each migration file in order:

```
supabase/migrations/0001_initial_schema.sql
supabase/migrations/0002_rls_policies.sql
supabase/migrations/0003_seed_data.sql
```

Or use the Supabase CLI:

```bash
npx supabase db push
```

### 5. Environment variables

Copy `.env.example` to `.env.local` and fill in your values:

```bash
cp .env.example .env.local
```

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project-ref.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key
NEXT_PUBLIC_SITE_URL=http://localhost:3000
TELEGRAM_BOT_TOKEN=your-bot-token
TELEGRAM_CHAT_ID=your-chat-id
```

### 6. Create the first admin user

The admin login uses Supabase Auth + a whitelist table. To add yourself:

**Step A** — Create the auth user in Supabase Dashboard → **Authentication → Users → Add user**

**Step B** — Add them to the `admins` table (SQL Editor):

```sql
-- Replace values with your actual user id and email
insert into public.admins (id, email, full_name)
values (
  'paste-auth-user-id-here',
  'admin@ekusweetcake.com',
  'Store Admin'
);
```

The `id` comes from the Authentication → Users table (copy the UUID).

### 7. Set up Telegram notifications (optional)

1. Message [@BotFather](https://t.me/BotFather) → `/newbot` → copy the token
2. Add the bot to a group, or message it directly, then find the chat ID via `https://api.telegram.org/bot<TOKEN>/getUpdates`
3. Paste `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID` in `.env.local`

### 8. Run locally

```bash
npm run dev
```

Visit `http://localhost:3000` for the storefront and `http://localhost:3000/admin/login` for the admin panel.

---

## PWA Icons

The `/public/icons/` folder contains SVG placeholders. For production:

1. Design a 1024×1024 PNG logo
2. Go to [realfavicongenerator.net](https://realfavicongenerator.net) or [pwa-asset-generator.com](https://pwa-asset-generator.com)
3. Download the icon pack and replace the files in `/public/icons/`

---

## Deployment (Vercel — recommended)

```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel
```

Add all environment variables in the Vercel dashboard under **Project → Settings → Environment Variables**.

Change `NEXT_PUBLIC_SITE_URL` to your production domain (e.g. `https://ekusweetcake.com`).

---

## Adding New Categories / Products

Everything is admin-driven — no code changes needed:

1. Log in at `/admin/login`
2. Go to **Categories → New Category** to add a new category
3. Go to **Products → New Product**, select the new category, set prices and rules

---

## Payment Method Configuration

1. Log in to admin → **Settings**
2. Enable/disable Cash on Delivery, Telebirr, CBE Birr
3. Set the Telebirr / CBE account numbers shown to customers

---

## Order Flow

```
Customer → Cart → Checkout → Server Action (placeOrder)
  → Supabase (insert order + items via service role)
  → Telegram notification
  → Redirect to /order-success/[orderNumber]
```

Admin updates status from **Orders** page → status shown in Telegram thread.

---

## Environment Variables Reference

| Variable | Where used | Required |
|---|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | All Supabase clients | ✅ |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Browser & server Supabase client | ✅ |
| `SUPABASE_SERVICE_ROLE_KEY` | Admin Supabase client (server-only) | ✅ |
| `NEXT_PUBLIC_SITE_URL` | PWA metadata, absolute URLs | ✅ |
| `TELEGRAM_BOT_TOKEN` | Order notifications | Optional |
| `TELEGRAM_CHAT_ID` | Order notifications | Optional |

---

## License

MIT © Eku Sweet Cake
