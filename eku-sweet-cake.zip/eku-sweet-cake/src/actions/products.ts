"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { productSchema, type ProductInput } from "@/lib/validations";
import type { ActionResult, ProductWithRelations } from "@/types/database";

// ── Read ─────────────────────────────────────────────────────────────────────

export async function getProducts(): Promise<ProductWithRelations[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .select(`*, category:categories(*), images:product_images(*), prices:product_prices(*)`)
    .order("sort_order", { ascending: true })
    .order("name_en", { ascending: true });

  if (error) {
    console.error("[getProducts]", error.message);
    return [];
  }
  return (data ?? []) as ProductWithRelations[];
}

export async function getAvailableProducts(): Promise<ProductWithRelations[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .select(`*, category:categories(*), images:product_images(*), prices:product_prices(*)`)
    .eq("is_available", true)
    .order("sort_order", { ascending: true });

  if (error) {
    console.error("[getAvailableProducts]", error.message);
    return [];
  }
  return (data ?? []) as ProductWithRelations[];
}

export async function getProductsByCategory(
  categorySlug: string
): Promise<ProductWithRelations[]> {
  const supabase = await createClient();

  const { data: cat } = await supabase
    .from("categories")
    .select("id")
    .eq("slug", categorySlug)
    .single();

  if (!cat) return [];

  const { data, error } = await supabase
    .from("products")
    .select(`*, category:categories(*), images:product_images(*), prices:product_prices(*)`)
    .eq("category_id", cat.id)
    .eq("is_available", true)
    .order("sort_order", { ascending: true });

  if (error) return [];
  return (data ?? []) as ProductWithRelations[];
}

export async function getProductById(id: string): Promise<ProductWithRelations | null> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .select(`*, category:categories(*), images:product_images(*), prices:product_prices(*)`)
    .eq("id", id)
    .single();

  if (error) return null;
  return data as ProductWithRelations;
}

export async function getFeaturedProducts(limit = 6): Promise<ProductWithRelations[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("products")
    .select(`*, category:categories(*), images:product_images(*), prices:product_prices(*)`)
    .eq("is_available", true)
    .order("sort_order", { ascending: true })
    .limit(limit);

  if (error) return [];
  return (data ?? []) as ProductWithRelations[];
}

// ── Create ────────────────────────────────────────────────────────────────────

export async function createProduct(
  input: ProductInput
): Promise<ActionResult<{ id: string }>> {
  const parsed = productSchema.safeParse(input);
  if (!parsed.success) {
    return { success: false, error: parsed.error.errors[0]?.message ?? "Validation failed." };
  }

  const supabase = await createClient();
  const { data: product, error: prodErr } = await supabase
    .from("products")
    .insert({
      category_id: parsed.data.categoryId,
      name_en: parsed.data.nameEn,
      name_am: parsed.data.nameAm,
      description_en: parsed.data.descriptionEn,
      description_am: parsed.data.descriptionAm,
      is_available: parsed.data.isAvailable,
      require_message: parsed.data.requireMessage,
      require_schedule_date: parsed.data.requireScheduleDate,
      require_advance_payment: parsed.data.requireAdvancePayment,
      minimum_notice_days: parsed.data.minimumNoticeDays,
      sort_order: parsed.data.sortOrder,
    })
    .select("id")
    .single();

  if (prodErr) return { success: false, error: prodErr.message };

  // Insert price options
  if (parsed.data.prices.length > 0) {
    const { error: priceErr } = await supabase.from("product_prices").insert(
      parsed.data.prices.map((p, idx) => ({
        product_id: product.id,
        label: p.label,
        price: p.price,
        sort_order: p.sortOrder ?? idx,
      }))
    );
    if (priceErr) return { success: false, error: priceErr.message };
  }

  revalidatePath("/admin/products");
  revalidatePath("/");
  return { success: true, data: { id: product.id } };
}

// ── Update ────────────────────────────────────────────────────────────────────

export async function updateProduct(
  id: string,
  input: ProductInput
): Promise<ActionResult<{ id: string }>> {
  const parsed = productSchema.safeParse(input);
  if (!parsed.success) {
    return { success: false, error: parsed.error.errors[0]?.message ?? "Validation failed." };
  }

  const supabase = await createClient();

  const { error: prodErr } = await supabase
    .from("products")
    .update({
      category_id: parsed.data.categoryId,
      name_en: parsed.data.nameEn,
      name_am: parsed.data.nameAm,
      description_en: parsed.data.descriptionEn,
      description_am: parsed.data.descriptionAm,
      is_available: parsed.data.isAvailable,
      require_message: parsed.data.requireMessage,
      require_schedule_date: parsed.data.requireScheduleDate,
      require_advance_payment: parsed.data.requireAdvancePayment,
      minimum_notice_days: parsed.data.minimumNoticeDays,
      sort_order: parsed.data.sortOrder,
    })
    .eq("id", id);

  if (prodErr) return { success: false, error: prodErr.message };

  // Replace all price options
  await supabase.from("product_prices").delete().eq("product_id", id);
  if (parsed.data.prices.length > 0) {
    const { error: priceErr } = await supabase.from("product_prices").insert(
      parsed.data.prices.map((p, idx) => ({
        product_id: id,
        label: p.label,
        price: p.price,
        sort_order: p.sortOrder ?? idx,
      }))
    );
    if (priceErr) return { success: false, error: priceErr.message };
  }

  revalidatePath(`/admin/products/${id}/edit`);
  revalidatePath("/admin/products");
  revalidatePath(`/product/${id}`);
  revalidatePath("/");
  return { success: true, data: { id } };
}

// ── Delete ────────────────────────────────────────────────────────────────────

export async function deleteProduct(id: string): Promise<ActionResult> {
  const supabase = await createClient();

  // Fetch images first so we can delete from storage
  const { data: images } = await supabase
    .from("product_images")
    .select("url")
    .eq("product_id", id);

  const { error } = await supabase.from("products").delete().eq("id", id);
  if (error) return { success: false, error: error.message };

  // Clean up storage objects (best-effort)
  if (images && images.length > 0) {
    const adminClient = createAdminClient();
    const paths = images
      .map((img) => {
        const url = img.url;
        const marker = "/object/public/products/";
        const idx = url.indexOf(marker);
        return idx !== -1 ? url.slice(idx + marker.length) : null;
      })
      .filter(Boolean) as string[];

    if (paths.length > 0) {
      await adminClient.storage.from("products").remove(paths);
    }
  }

  revalidatePath("/admin/products");
  revalidatePath("/");
  return { success: true, data: undefined };
}

// ── Image management ─────────────────────────────────────────────────────────

export async function deleteProductImage(
  imageId: string,
  storagePath: string
): Promise<ActionResult> {
  const supabase = await createClient();

  const { error: dbErr } = await supabase
    .from("product_images")
    .delete()
    .eq("id", imageId);

  if (dbErr) return { success: false, error: dbErr.message };

  const adminClient = createAdminClient();
  await adminClient.storage.from("products").remove([storagePath]);

  return { success: true, data: undefined };
}

export async function addProductImageRecord(
  productId: string,
  url: string,
  sortOrder: number
): Promise<ActionResult<{ id: string }>> {
  const supabase = await createClient();

  const { data, error } = await supabase
    .from("product_images")
    .insert({ product_id: productId, url, sort_order: sortOrder })
    .select("id")
    .single();

  if (error) return { success: false, error: error.message };
  return { success: true, data: { id: data.id } };
}
