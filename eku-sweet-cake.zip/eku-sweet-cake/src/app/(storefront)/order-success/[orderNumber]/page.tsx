import Link from "next/link";
import { CheckCircle2 } from "lucide-react";
import { getOrderByNumber } from "@/actions/orders";
import { formatCurrency } from "@/lib/utils";

export const dynamic = "force-dynamic";

interface Props {
  params: Promise<{ orderNumber: string }>;
}

export default async function OrderSuccessPage({ params }: Props) {
  const { orderNumber } = await params;
  const order = await getOrderByNumber(Number(orderNumber));

  const PAYMENT_LABELS: Record<string, string> = {
    cod: "Cash on Delivery",
    telebirr: "Telebirr",
    cbe_birr: "CBE Birr",
  };

  return (
    <div className="mx-auto max-w-lg px-4 py-16 text-center">
      <div className="mb-6 flex justify-center">
        <div className="flex h-20 w-20 items-center justify-center rounded-full bg-green-100">
          <CheckCircle2 size={40} className="text-green-500" />
        </div>
      </div>

      <h1 className="mb-2 text-2xl font-bold text-accent">Order Placed! 🎉</h1>
      <p className="mb-6 text-accent-light text-sm">
        Thank you for your order. We will contact you shortly to confirm.
      </p>

      <div className="card mb-6 p-6 text-left">
        <div className="mb-4 flex items-center justify-between">
          <span className="text-sm text-accent-light">Order Number</span>
          <span className="text-lg font-bold text-primary">#{order?.order_number ?? orderNumber}</span>
        </div>

        {order && (
          <>
            <div className="mb-4 border-t border-accent-200 pt-4 flex flex-col gap-2">
              {order.items.map((item) => (
                <div key={item.id} className="flex items-center justify-between text-sm">
                  <div>
                    <span className="font-medium text-accent">{item.product_name_en}</span>
                    {item.price_label && <span className="text-accent-light"> ({item.price_label})</span>}
                    <span className="text-accent-light"> ×{item.quantity}</span>
                    {item.cake_message && <p className="text-xs text-accent-light">✏️ {item.cake_message}</p>}
                    {item.schedule_date && <p className="text-xs text-accent-light">📅 {item.schedule_date}</p>}
                  </div>
                  <span className="font-semibold text-accent">{formatCurrency(item.line_total)}</span>
                </div>
              ))}
            </div>

            <div className="flex items-center justify-between font-bold">
              <span className="text-accent">Total</span>
              <span className="text-primary">{formatCurrency(order.total)}</span>
            </div>

            <div className="mt-4 flex items-center justify-between text-sm">
              <span className="text-accent-light">Payment</span>
              <span className="font-medium text-accent">{PAYMENT_LABELS[order.payment_method]}</span>
            </div>
          </>
        )}
      </div>

      <Link href="/" className="btn-primary">
        Continue Shopping
      </Link>
    </div>
  );
}
