"use client";

import { useState, useEffect } from "react";
import { getSettings, updateSettings } from "@/actions/settings";
import type { PaymentSettings } from "@/types/database";

export default function AdminSettingsPage() {
  const [settings, setSettings] = useState<PaymentSettings | null>(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    getSettings().then(setSettings);
  }, []);

  async function handleSave() {
    if (!settings) return;
    setSaving(true);
    setError("");
    const result = await updateSettings(settings);
    setSaving(false);
    if (!result.success) { setError(result.error); return; }
    setSaved(true);
    setTimeout(() => setSaved(false), 2500);
  }

  const Toggle = ({
    label,
    description,
    checked,
    onChange,
  }: {
    label: string;
    description: string;
    checked: boolean;
    onChange: (v: boolean) => void;
  }) => (
    <div className="flex items-center justify-between py-4 border-b border-accent-200 last:border-0">
      <div>
        <p className="font-medium text-accent text-sm">{label}</p>
        <p className="text-xs text-accent-light mt-0.5">{description}</p>
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={`relative h-7 w-12 rounded-full transition-colors flex-shrink-0 ml-4 ${checked ? "bg-primary" : "bg-accent-200"}`}
      >
        <div className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-transform ${checked ? "translate-x-6" : "translate-x-1"}`} />
      </button>
    </div>
  );

  if (!settings) {
    return (
      <div className="p-6 flex items-center justify-center py-20">
        <p className="text-accent-light animate-pulse">Loading settings…</p>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-lg">
      <h1 className="mb-6 text-2xl font-bold text-accent">Settings</h1>

      <div className="card p-6 mb-5">
        <h2 className="mb-4 font-bold text-accent">Payment Methods</h2>

        <Toggle
          label="Cash on Delivery"
          description="Allow customers to pay when order is delivered."
          checked={settings.codEnabled}
          onChange={(v) => setSettings((s) => s ? { ...s, codEnabled: v } : s)}
        />
        <Toggle
          label="Telebirr"
          description="Allow Telebirr mobile money payments."
          checked={settings.telebirrEnabled}
          onChange={(v) => setSettings((s) => s ? { ...s, telebirrEnabled: v } : s)}
        />
        <Toggle
          label="CBE Birr"
          description="Allow CBE Birr mobile banking payments."
          checked={settings.cbeEnabled}
          onChange={(v) => setSettings((s) => s ? { ...s, cbeEnabled: v } : s)}
        />
      </div>

      <div className="card p-6 mb-5">
        <h2 className="mb-4 font-bold text-accent">Payment Numbers</h2>
        <p className="mb-4 text-xs text-accent-light">
          These numbers are shown to customers who select Telebirr or CBE Birr at checkout.
        </p>

        <div className="flex flex-col gap-4">
          <div>
            <label className="field-label">Telebirr Number</label>
            <input
              type="tel"
              className="field-input"
              value={settings.telebirrNumber}
              onChange={(e) => setSettings((s) => s ? { ...s, telebirrNumber: e.target.value } : s)}
              placeholder="09xxxxxxxx"
            />
          </div>
          <div>
            <label className="field-label">CBE Birr Account</label>
            <input
              type="text"
              className="field-input"
              value={settings.cbeNumber}
              onChange={(e) => setSettings((s) => s ? { ...s, cbeNumber: e.target.value } : s)}
              placeholder="100xxxxxxxxx"
            />
          </div>
        </div>
      </div>

      {error && (
        <div className="mb-4 rounded-2xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-600">
          {error}
        </div>
      )}

      <button
        onClick={handleSave}
        disabled={saving}
        className={`btn-primary ${saved ? "!bg-green-500" : ""}`}
      >
        {saving ? "Saving…" : saved ? "Saved! ✓" : "Save Settings"}
      </button>
    </div>
  );
}
