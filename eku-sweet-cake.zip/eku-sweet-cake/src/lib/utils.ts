import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

/** Merges Tailwind classes without conflicts. */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/** Format a number as Ethiopian Birr. */
export function formatCurrency(amount: number): string {
  return `${amount.toLocaleString("en-ET")} ETB`;
}

/** Format an ISO date string to a readable local date. */
export function formatDate(date: string | Date, locale = "en-ET"): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleDateString(locale, {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

/** Format a date+time. */
export function formatDateTime(date: string | Date, locale = "en-ET"): string {
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleString(locale, {
    year: "numeric",
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

/** Convert a string to a URL-safe slug. */
export function slugify(text: string): string {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^\w\s-]/g, "")
    .replace(/[\s_-]+/g, "-")
    .replace(/^-+|-+$/g, "");
}

/**
 * Returns the earliest selectable delivery date (ISO date string YYYY-MM-DD)
 * given a minimum-notice requirement in days.
 */
export function minDeliveryDate(minimumNoticeDays: number): string {
  const d = new Date();
  d.setDate(d.getDate() + Math.max(minimumNoticeDays, 1));
  return d.toISOString().split("T")[0];
}

/** True if `orderNumber` is today's. */
export function isToday(dateString: string): boolean {
  const d = new Date(dateString);
  const now = new Date();
  return (
    d.getFullYear() === now.getFullYear() &&
    d.getMonth() === now.getMonth() &&
    d.getDate() === now.getDate()
  );
}

/** True if `dateString` falls in the current calendar month. */
export function isThisMonth(dateString: string): boolean {
  const d = new Date(dateString);
  const now = new Date();
  return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth();
}

/** Generate a short random id (for cart line items). */
export function generateId(): string {
  return Math.random().toString(36).slice(2, 10);
}

/** Map a Supabase storage path to a public URL. */
export function storageUrl(path: string): string {
  return `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/products/${path}`;
}
