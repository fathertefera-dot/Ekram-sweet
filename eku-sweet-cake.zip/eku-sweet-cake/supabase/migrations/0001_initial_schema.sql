-- =============================================================================
-- Eku Sweet Cake — Migration 0001: Initial schema
-- =============================================================================
-- Creates all core tables for the storefront + admin panel:
--   categories, products, product_images, product_prices,
--   orders, order_items, settings, admins
-- Plus helper triggers for `updated_at` bookkeeping and a hard limit of
-- 10 images per product.
-- =============================================================================

create extension if not exists "pgcrypto";

-- -----------------------------------------------------------------------
-- Helper: keep `updated_at` fresh on every UPDATE
-- -----------------------------------------------------------------------
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- -----------------------------------------------------------------------
-- admins
-- One row per admin user. `id` mirrors the Supabase Auth user id, so an
-- authenticated user is an admin if (and only if) a row with the same id
-- exists here. Rows are created manually (see supabase/README.md) — there
-- is no public sign-up flow.
-- -----------------------------------------------------------------------
create table if not exists public.admins (
  id uuid primary key references auth.users (id) on delete cascade,
  full_name text not null default '',
  email text not null,
  created_at timestamptz not null default now()
);

-- -----------------------------------------------------------------------
-- categories
-- Admin-managed, unlimited categories (Birthday Cake, Burger, Chocolate, ...)
-- -----------------------------------------------------------------------
create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name_en text not null,
  name_am text not null,
  slug text not null unique,
  description_en text not null default '',
  description_am text not null default '',
  image_url text,
  sort_order integer not null default 0,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint categories_slug_format check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$')
);

create index if not exists categories_sort_order_idx on public.categories (sort_order, name_en);
create index if not exists categories_is_active_idx on public.categories (is_active);

drop trigger if exists categories_set_updated_at on public.categories;
create trigger categories_set_updated_at
  before update on public.categories
  for each row execute function public.set_updated_at();

-- -----------------------------------------------------------------------
-- products
-- Flexible per-product ordering rules live directly on the row so the
-- admin panel can change behaviour without a code change/deploy.
-- -----------------------------------------------------------------------
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  category_id uuid not null references public.categories (id) on delete restrict,
  name_en text not null,
  name_am text not null,
  description_en text not null default '',
  description_am text not null default '',
  is_available boolean not null default true,

  -- Flexible product rules (admin-configurable, never hardcoded)
  require_message boolean not null default false,
  require_schedule_date boolean not null default false,
  require_advance_payment boolean not null default false,
  minimum_notice_days integer not null default 0,

  sort_order integer not null default 0,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint products_minimum_notice_days_check check (minimum_notice_days >= 0 and minimum_notice_days <= 60)
);

create index if not exists products_category_id_idx on public.products (category_id);
create index if not exists products_is_available_idx on public.products (is_available);
create index if not exists products_sort_order_idx on public.products (sort_order, name_en);

drop trigger if exists products_set_updated_at on public.products;
create trigger products_set_updated_at
  before update on public.products
  for each row execute function public.set_updated_at();

-- -----------------------------------------------------------------------
-- product_images
-- Up to 10 images per product, ordered by `sort_order`.
-- -----------------------------------------------------------------------
create table if not exists public.product_images (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products (id) on delete cascade,
  url text not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now()
);

create index if not exists product_images_product_id_idx on public.product_images (product_id, sort_order);

-- Enforce the "max 10 images" business rule at the database level too.
create or replace function public.enforce_product_image_limit()
returns trigger
language plpgsql
as $$
declare
  image_count integer;
begin
  select count(*) into image_count
  from public.product_images
  where product_id = new.product_id;

  if image_count >= 10 then
    raise exception 'A product cannot have more than 10 images';
  end if;

  return new;
end;
$$;

drop trigger if exists product_images_limit_check on public.product_images;
create trigger product_images_limit_check
  before insert on public.product_images
  for each row execute function public.enforce_product_image_limit();

-- -----------------------------------------------------------------------
-- product_prices
-- Multiple price options per product (e.g. 500 / 1000 / 1500 / 2000 ETB)
-- -----------------------------------------------------------------------
create table if not exists public.product_prices (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products (id) on delete cascade,
  label text not null default '',
  price numeric(10, 2) not null,
  sort_order integer not null default 0,
  created_at timestamptz not null default now(),

  constraint product_prices_price_positive check (price > 0)
);

create index if not exists product_prices_product_id_idx on public.product_prices (product_id, sort_order);

-- -----------------------------------------------------------------------
-- orders
-- `order_number` is a friendly, sequential, human-readable identifier
-- (e.g. "#1054") shown to customers, admins and in Telegram alerts.
-- -----------------------------------------------------------------------
create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number bigint generated always as identity (start with 1001 increment by 1) unique,

  customer_name text not null,
  customer_phone text not null,
  delivery_address text not null,
  additional_note text not null default '',

  payment_method text not null,
  status text not null default 'pending',

  subtotal numeric(10, 2) not null,
  total numeric(10, 2) not null,

  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),

  constraint orders_payment_method_check
    check (payment_method in ('cod', 'telebirr', 'cbe_birr')),
  constraint orders_status_check
    check (status in ('pending', 'confirmed', 'preparing', 'out_for_delivery', 'delivered', 'cancelled')),
  constraint orders_amounts_check check (subtotal >= 0 and total >= 0)
);

create index if not exists orders_status_idx on public.orders (status);
create index if not exists orders_created_at_idx on public.orders (created_at desc);
create unique index if not exists orders_order_number_idx on public.orders (order_number);

drop trigger if exists orders_set_updated_at on public.orders;
create trigger orders_set_updated_at
  before update on public.orders
  for each row execute function public.set_updated_at();

-- -----------------------------------------------------------------------
-- order_items
-- Snapshots product name + price at the time of order so historical
-- orders remain accurate even if the product is edited or removed later.
-- -----------------------------------------------------------------------
create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders (id) on delete cascade,
  product_id uuid references public.products (id) on delete set null,

  product_name_en text not null,
  product_name_am text not null,
  price_label text not null default '',
  unit_price numeric(10, 2) not null,
  quantity integer not null default 1,
  line_total numeric(10, 2) not null,

  -- Birthday-cake style customisation (nullable — only used when the
  -- product's rules require them)
  cake_message text,
  schedule_date date,

  created_at timestamptz not null default now(),

  constraint order_items_quantity_check check (quantity > 0),
  constraint order_items_unit_price_check check (unit_price >= 0),
  constraint order_items_line_total_check check (line_total >= 0)
);

create index if not exists order_items_order_id_idx on public.order_items (order_id);
create index if not exists order_items_product_id_idx on public.order_items (product_id);

-- -----------------------------------------------------------------------
-- settings
-- Simple key/value store for store-wide configuration (payment toggles,
-- mobile money numbers, etc.) so the admin panel can manage them without
-- code changes.
-- -----------------------------------------------------------------------
create table if not exists public.settings (
  key text primary key,
  value text not null default '',
  updated_at timestamptz not null default now()
);

drop trigger if exists settings_set_updated_at on public.settings;
create trigger settings_set_updated_at
  before update on public.settings
  for each row execute function public.set_updated_at();
