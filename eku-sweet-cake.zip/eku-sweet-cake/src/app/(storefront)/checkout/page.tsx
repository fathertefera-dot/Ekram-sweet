"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { useCartStore } from "@/store/cart";
import { getTranslations } from "@/lib/i18n/translations";
import { formatCurrency } from "@/lib/utils";
import { placeOrder } from "@/actions/orders";
import { getSettings } from "@/actions/settings";
import type { PaymentMethod, PaymentSettings } from "@/types/database";

export default function CheckoutPage() {
  const { items, locale, subtotal, clearCart } = useCartStore();
  const t = getTranslations(locale);
  const router = useRouter();

  const [settings, setSettings] = useState<PaymentSettings | null>(null);
  const [form, setForm] = useState({
    customerName: "",
    customerPhone: "",
    deliveryAddress: "",
    additionalNote: "",
    paymentMethod: "" as PaymentMethod | "",
  });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [globalError, setGlobalError] = useState("");

  // Detect if any item requires advance payment (disables COD)
  const requiresAdvancePayment = items.some((i) => i.requireAdvancePayment);

  useEffect(() => {
    getSettings().then((s) => {
      setSettings(s);
      // Auto-select first available payment method
      const first = s.codEnabled && !requiresAdvancePayment
        ? "cod"
        : s.telebirrEnabled ? "telebirr"
        : s.cbeEnabled ? "cbe_birr"
        : "";
      setForm((f) => ({ ...f, paymentMethod: first as PaymentMethod | "" }));
    });
  }, [requiresAdvancePayment]);

  function validate() {
    const e: Record<string, string> = {};
    if (!form.customerName.trim()) e.customerName = t.validationRequired;
    if (!/^(\+2519|09)\d{8}$/.test(form.customerPhone.replace(/\s/g, "")))
      e.customerPhone = t.validationPhone;
    if (form.deliveryAddress.trim().length < 5)
      e.deliveryAddress = t.validationRequired;
    if (!form.paymentMethod) e.paymentMethod = t.validationRequired;
    return e;
  }

  async function handleSubmit() {
    if (items.length === 0) return;
    const e = validate();
    if (Object.keys(e).length) { setErrors(e); return; }

    setLoading(true);
    setGlobalError("");

    const result = await placeOrder({
      customerName: form.customerName.trim(),
      customerPhone: form.customerPhone.replace(/\s/g, ""),
      deliveryAddress: form.deliveryAddress.trim(),
      additionalNote: form.additionalNote.trim(),
      paymentMethod: form.paymentMethod as PaymentMethod,
      items,
    });

    setLoading(false);

    if (!result.success) {
      setGlobalError(result.error);
      return;
    }

    clearCart();
    router.push(`/order-success/${result.data.orderNumber}`);
  }

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center px-4 py-24 text-center">
        <p className="mb-4 text-accent-light">Your cart is empty.</p>
        <Link href="/categories" className="btn-primary">Browse Menu</Link>
      </div>
    );
  }

  const paymentMethods: { key: PaymentMethod; label: string; number?: string }[] = [];
  if (settings) {
    if (settings.codEnabled && !requiresAdvancePayment)
      paymentMethods.push({ key: "cod", label: t.cashOnDelivery });
    if (settings.telebirrEnabled)
      paymentMethods.push({ key: "telebirr", label: t.telebirr, number: settings.telebirrNumber });
    if (settings.cbeEnabled)
      paymentMethods.push({ key: "cbe_birr", label: t.cbeBirr, number: settings.cbeNumber });
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <h1 className="mb-6 text-2xl font-bold text-accent">{t.checkout}</h1>

      <div className="flex flex-col gap-4">
        {/* Customer details */}
        <div className="card p-5">
          <h2 className="mb-4 font-bold text-accent">{t.customerDetails}</h2>
          <div className="flex flex-col gap-4">
            <div>
              <label className="field-label">{t.fullName}</label>
              <input
                type="text"
                value={form.customerName}
                onChange={(e) => { setForm((f) => ({ ...f, customerName: e.target.value })); setErrors((er) => ({ ...er, customerName: "" })); }}
                placeholder={t.fullNamePlaceholder}
                className="field-input"
              />
              {errors.customerName && <p className="mt-1 text-xs text-red-500">{errors.customerName}</p>}
            </div>

            <div>
              <label className="field-label">{t.phone}</label>
              <input
                type="tel"
                value={form.customerPhone}
                onChange={(e) => { setForm((f) => ({ ...f, customerPhone: e.target.value })); setErrors((er) => ({ ...er, customerPhone: "" })); }}
                placeholder={t.phonePlaceholder}
                className="field-input"
              />
              {errors.customerPhone && <p className="mt-1 text-xs text-red-500">{errors.customerPhone}</p>}
            </div>

            <div>
              <label className="field-label">{t.deliveryAddress}</label>
              <textarea
                rows={2}
                value={form.deliveryAddress}
                onChange={(e) => { setForm((f) => ({ ...f, deliveryAddress: e.target.value })); setErrors((er) => ({ ...er, deliveryAddress: "" })); }}
                placeholder={t.deliveryAddressPlaceholder}
                className="field-input resize-none"
              />
              {errors.deliveryAddress && <p className="mt-1 text-xs text-red-500">{errors.deliveryAddress}</p>}
            </div>

            <div>
              <label className="field-label">{t.additionalNote} <span className="normal-case font-normal text-accent-light/70">({t.optional})</span></label>
              <textarea
                rows={2}
                value={form.additionalNote}
                onChange={(e) => setForm((f) => ({ ...f, additionalNote: e.target.value }))}
                placeholder={t.additionalNotePlaceholder}
                className="field-input resize-none"
              />
            </div>
          </div>
        </div>

        {/* Payment */}
        <div className="card p-5">
          <h2 className="mb-4 font-bold text-accent">{t.paymentMethod}</h2>

          {requiresAdvancePayment && (
            <div className="mb-4 rounded-2xl bg-yellow-50 border border-yellow-200 px-4 py-3 text-xs text-yellow-800">
              {t.advancePaymentRequired}
            </div>
          )}

          {settings === null ? (
            <p className="text-sm text-accent-light">{t.loading}</p>
          ) : paymentMethods.length === 0 ? (
            <p className="text-sm text-accent-light">No payment methods are available right now. Please contact us.</p>
          ) : (
            <div className="flex flex-col gap-2">
              {paymentMethods.map((pm) => (
                <button
                  key={pm.key}
                  onClick={() => { setForm((f) => ({ ...f, paymentMethod: pm.key })); setErrors((er) => ({ ...er, paymentMethod: "" })); }}
                  className={`flex items-center justify-between rounded-2xl border-2 px-4 py-3.5 text-sm font-semibold transition-all text-left ${
                    form.paymentMethod === pm.key
                      ? "border-primary bg-primary/5 text-primary"
                      : "border-accent-200 bg-white text-accent hover:border-primary/40"
                  }`}
                >
                  <span>{pm.label}</span>
                  {pm.number && form.paymentMethod === pm.key && (
                    <span className="text-xs font-normal text-accent-light">
                      {t.payTo} <strong>{pm.number}</strong>
                    </span>
                  )}
                </button>
              ))}
            </div>
          )}
          {errors.paymentMethod && <p className="mt-2 text-xs text-red-500">{errors.paymentMethod}</p>}
        </div>

        {/* Order summary */}
        <div className="card p-5">
          <h2 className="mb-4 font-bold text-accent">{t.orderSummary}</h2>
          <div className="flex flex-col gap-2">
            {items.map((item) => (
              <div key={item.id} className="flex items-center justify-between text-sm">
                <span className="text-accent">
                  {locale === "am" ? item.nameAm : item.nameEn}
                  {item.priceLabel ? ` (${item.priceLabel})` : ""} ×{item.quantity}
                </span>
                <span className="font-semibold text-accent">{formatCurrency(item.unitPrice * item.quantity)}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 border-t border-accent-200 pt-4 flex items-center justify-between font-bold">
            <span className="text-accent">{t.total}</span>
            <span className="text-primary text-lg">{formatCurrency(subtotal())}</span>
          </div>
        </div>

        {globalError && (
          <div className="rounded-2xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-600">
            {globalError}
          </div>
        )}

        <button
          onClick={handleSubmit}
          disabled={loading}
          className="btn-primary w-full py-4 text-base"
        >
          {loading ? t.loading : t.placeOrder}
        </button>
      </div>
    </div>
  );
}
