import { Header } from "@/components/layout/Header";
import { BottomNav } from "@/components/layout/BottomNav";

export default function StorefrontLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1 pb-20 sm:pb-6">{children}</main>
      <BottomNav />
      <footer className="hidden sm:block border-t border-accent-200/40 bg-white py-6">
        <div className="mx-auto max-w-6xl px-4 text-center text-xs text-accent-light">
          © {new Date().getFullYear()} Eku Sweet Cake — Addis Ababa. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
