import { notFound } from "next/navigation";
import Link from "next/link";
import Image from "next/image";
import type { Metadata } from "next";
import { getCategoryBySlug } from "@/actions/categories";
import { getProductsByCategory } from "@/actions/products";
import { formatCurrency } from "@/lib/utils";

export const dynamic = "force-dynamic";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const cat = await getCategoryBySlug(slug);
  return { title: cat?.name_en ?? "Category" };
}

export default async function CategoryPage({ params }: Props) {
  const { slug } = await params;
  const [category, products] = await Promise.all([
    getCategoryBySlug(slug),
    getProductsByCategory(slug),
  ]);

  if (!category) notFound();

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      {/* Breadcrumb */}
      <nav className="mb-5 flex items-center gap-2 text-xs text-accent-light">
        <Link href="/" className="hover:text-primary">Home</Link>
        <span>/</span>
        <Link href="/categories" className="hover:text-primary">Categories</Link>
        <span>/</span>
        <span className="text-accent">{category.name_en}</span>
      </nav>

      <h1 className="mb-6 text-2xl font-bold text-accent">{category.name_en}</h1>

      {products.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <span className="mb-3 text-5xl">🍽️</span>
          <p className="text-accent-light">No products in this category yet.</p>
          <Link href="/categories" className="mt-4 text-sm font-medium text-primary hover:underline">
            Browse other categories
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
          {products.map((product) => {
            const firstImage = product.images?.[0]?.url;
            const lowestPrice = product.prices?.reduce(
              (min, p) => (p.price < min ? p.price : min),
              product.prices[0]?.price ?? 0
            );

            return (
              <Link
                key={product.id}
                href={`/product/${product.id}`}
                className="card group flex flex-col overflow-hidden transition-transform hover:-translate-y-1 active:scale-95"
              >
                <div className="relative aspect-square w-full overflow-hidden bg-secondary">
                  {firstImage ? (
                    <Image
                      src={firstImage}
                      alt={product.name_en}
                      fill
                      className="object-cover transition-transform duration-300 group-hover:scale-105"
                      sizes="(max-width: 640px) 50vw, 25vw"
                    />
                  ) : (
                    <div className="flex h-full items-center justify-center text-4xl">🎂</div>
                  )}
                  {!product.is_available && (
                    <span className="absolute left-2 top-2 rounded-full bg-accent/80 px-2 py-0.5 text-[10px] font-bold text-white">
                      Out of Stock
                    </span>
                  )}
                </div>
                <div className="flex flex-1 flex-col p-3">
                  <p className="mb-1 line-clamp-2 text-sm font-bold text-accent group-hover:text-primary transition-colors">
                    {product.name_en}
                  </p>
                  {lowestPrice > 0 && (
                    <p className="mt-auto text-sm font-bold text-primary">
                      {product.prices.length > 1 ? "From " : ""}
                      {formatCurrency(lowestPrice)}
                    </p>
                  )}
                </div>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
