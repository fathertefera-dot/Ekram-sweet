import Link from "next/link";
import Image from "next/image";
import { ChevronRight, Star, Truck, Zap } from "lucide-react";
import { getFeaturedProducts } from "@/actions/products";
import { getActiveCategories } from "@/actions/categories";
import { formatCurrency, localeName } from "@/lib/utils";
import type { Locale } from "@/types/database";

// Force dynamic so category/product updates reflect immediately
export const dynamic = "force-dynamic";

// We read locale from a cookie client-side; server defaults to English.
// For full server-side locale, add a cookie read here.
const locale: Locale = "en";

export default async function HomePage() {
  const [products, categories] = await Promise.all([
    getFeaturedProducts(6),
    getActiveCategories(),
  ]);

  return (
    <div>
      {/* ── Hero ─────────────────────────────────────────────────────── */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary via-primary-600 to-primary-700 px-4 py-16 text-white sm:py-24">
        {/* Decorative blobs */}
        <div className="absolute -right-16 -top-16 h-64 w-64 rounded-full bg-white/10 blur-3xl" />
        <div className="absolute -bottom-20 -left-10 h-80 w-80 rounded-full bg-primary-800/30 blur-3xl" />

        <div className="relative mx-auto max-w-6xl">
          <div className="max-w-xl">
            <span className="mb-4 inline-flex items-center gap-2 rounded-full bg-white/20 px-3 py-1 text-xs font-semibold backdrop-blur-sm">
              🎂 Made fresh in Addis Ababa
            </span>
            <h1 className="mb-4 text-4xl font-bold leading-tight sm:text-5xl">
              Sweet Moments,
              <br />
              <span className="text-secondary">Delivered Fresh</span>
            </h1>
            <p className="mb-8 text-base text-white/80 sm:text-lg">
              Custom birthday cakes, handcrafted chocolates, and juicy burgers —
              all made to order, delivered to your door.
            </p>
            <div className="flex flex-wrap gap-3">
              <Link href="/categories" className="btn-primary !bg-white !text-primary !shadow-none hover:!bg-secondary">
                Order Now
              </Link>
              <Link href="/categories" className="btn-outline !border-white/30 !bg-white/10 !text-white backdrop-blur-sm hover:!bg-white/20">
                Explore Menu
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── Why choose us ────────────────────────────────────────────── */}
      <section className="bg-white px-4 py-10">
        <div className="mx-auto grid max-w-6xl grid-cols-3 gap-4 text-center">
          {[
            { icon: Star, title: "Fresh Ingredients", desc: "Only the finest local produce" },
            { icon: Truck, title: "Free Delivery", desc: "Free on every single order" },
            { icon: Zap, title: "Made to Order", desc: "Prepared fresh when you order" },
          ].map((item) => (
            <div key={item.title} className="flex flex-col items-center gap-2 px-2">
              <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-secondary">
                <item.icon size={20} className="text-primary" />
              </div>
              <p className="text-xs font-bold text-accent sm:text-sm">{item.title}</p>
              <p className="hidden text-xs text-accent-light sm:block">{item.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* ── Categories ───────────────────────────────────────────────── */}
      {categories.length > 0 && (
        <section className="px-4 py-10">
          <div className="mx-auto max-w-6xl">
            <div className="mb-5 flex items-center justify-between">
              <h2 className="section-title">Shop by Category</h2>
              <Link href="/categories" className="flex items-center gap-1 text-sm font-medium text-primary hover:underline">
                View All <ChevronRight size={14} />
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {categories.map((cat) => (
                <Link
                  key={cat.id}
                  href={`/categories/${cat.slug}`}
                  className="card group flex flex-col items-center gap-3 p-5 text-center transition-transform hover:-translate-y-1 active:scale-95"
                >
                  {cat.image_url ? (
                    <div className="relative h-16 w-16 overflow-hidden rounded-2xl">
                      <Image src={cat.image_url} alt={cat.name_en} fill className="object-cover" />
                    </div>
                  ) : (
                    <div className="flex h-16 w-16 items-center justify-center rounded-2xl bg-secondary text-3xl">
                      {cat.name_en === "Birthday Cake" ? "🎂"
                        : cat.name_en === "Burger" ? "🍔"
                        : cat.name_en === "Chocolate" ? "🍫"
                        : "🛍️"}
                    </div>
                  )}
                  <div>
                    <p className="font-bold text-accent text-sm group-hover:text-primary transition-colors">
                      {localeName(cat, locale)}
                    </p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* ── Featured products ─────────────────────────────────────────── */}
      {products.length > 0 && (
        <section className="bg-white px-4 py-10">
          <div className="mx-auto max-w-6xl">
            <div className="mb-5 flex items-center justify-between">
              <h2 className="section-title">Featured Products</h2>
              <Link href="/categories" className="flex items-center gap-1 text-sm font-medium text-primary hover:underline">
                View All <ChevronRight size={14} />
              </Link>
            </div>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
              {products.map((product) => {
                const firstImage = product.images?.[0]?.url;
                const lowestPrice = product.prices?.reduce(
                  (min, p) => (p.price < min ? p.price : min),
                  product.prices[0]?.price ?? 0
                );

                return (
                  <Link
                    key={product.id}
                    href={`/product/${product.id}`}
                    className="card group flex flex-col overflow-hidden transition-transform hover:-translate-y-1 active:scale-95"
                  >
                    <div className="relative aspect-square w-full overflow-hidden bg-secondary">
                      {firstImage ? (
                        <Image
                          src={firstImage}
                          alt={product.name_en}
                          fill
                          className="object-cover transition-transform duration-300 group-hover:scale-105"
                          sizes="(max-width: 640px) 50vw, 25vw"
                        />
                      ) : (
                        <div className="flex h-full items-center justify-center text-4xl">
                          🎂
                        </div>
                      )}
                      {!product.is_available && (
                        <span className="absolute left-2 top-2 rounded-full bg-accent/80 px-2 py-0.5 text-[10px] font-bold text-white">
                          Out of Stock
                        </span>
                      )}
                    </div>
                    <div className="flex flex-1 flex-col p-3">
                      <p className="mb-1 line-clamp-2 text-sm font-bold text-accent group-hover:text-primary transition-colors">
                        {localeName(product, locale)}
                      </p>
                      {lowestPrice > 0 && (
                        <p className="mt-auto text-sm font-bold text-primary">
                          {product.prices.length > 1 ? "From " : ""}
                          {formatCurrency(lowestPrice)}
                        </p>
                      )}
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>
        </section>
      )}

      {/* Bottom spacer for mobile nav */}
      <div className="h-4" />
    </div>
  );
}
