-- =============================================================================
-- Eku Sweet Cake — Migration 0003: Seed data
-- =============================================================================
-- Seeds the 3 starter categories (Birthday Cake, Burger, Chocolate), a
-- couple of example products in each (with price options, placeholder
-- images and the flexible rules described in the brief), plus default
-- store settings. Safe to re-run — every insert is guarded.
--
-- Replace the placehold.co image URLs with real photos uploaded through
-- the admin panel (Products -> Edit -> Photos) once the project is live.
-- =============================================================================

do $$
declare
  cat_cake_id uuid;
  cat_burger_id uuid;
  cat_choco_id uuid;

  prod_id uuid;
begin
  -- ---------------------------------------------------------------------
  -- Categories
  -- ---------------------------------------------------------------------
  insert into public.categories (name_en, name_am, slug, description_en, description_am, sort_order)
  values ('Birthday Cake', 'የልደት ኬክ', 'birthday-cake',
          'Custom cakes for birthdays and every celebration in between.',
          'ለልደት እና ለሁሉም ድግሶች የሚሆኑ ኬኮች።', 1)
  on conflict (slug) do nothing
  returning id into cat_cake_id;

  if cat_cake_id is null then
    select id into cat_cake_id from public.categories where slug = 'birthday-cake';
  end if;

  insert into public.categories (name_en, name_am, slug, description_en, description_am, sort_order)
  values ('Burger', 'በርገር', 'burger',
          'Juicy, freshly grilled burgers made to order.',
          'በትኩስ የተጠበሱ ጣፋጭ በርገሮች።', 2)
  on conflict (slug) do nothing
  returning id into cat_burger_id;

  if cat_burger_id is null then
    select id into cat_burger_id from public.categories where slug = 'burger';
  end if;

  insert into public.categories (name_en, name_am, slug, description_en, description_am, sort_order)
  values ('Chocolate', 'ቸኮሌት', 'chocolate',
          'Handcrafted chocolates and treats, perfect for gifting.',
          'ለስጦታ የሚሆኑ የእጅ ስራ ቸኮሌቶች።', 3)
  on conflict (slug) do nothing
  returning id into cat_choco_id;

  if cat_choco_id is null then
    select id into cat_choco_id from public.categories where slug = 'chocolate';
  end if;

  -- ---------------------------------------------------------------------
  -- Birthday Cake products
  -- ---------------------------------------------------------------------
  if not exists (select 1 from public.products where name_en = 'Classic Birthday Cake') then
    insert into public.products (
      category_id, name_en, name_am, description_en, description_am, is_available,
      require_message, require_schedule_date, require_advance_payment, minimum_notice_days, sort_order
    ) values (
      cat_cake_id, 'Classic Birthday Cake', 'ክላሲክ የልደት ኬክ',
      'A soft vanilla sponge cake with smooth buttercream frosting, customised with your message.',
      'ለስላሳ የቫኒላ ኬክ ከለስላሳ ክሬም ጋር፣ በመልዕክትዎ ተስተካክሎ የሚዘጋጅ።',
      true, true, true, true, 1, 1
    ) returning id into prod_id;

    insert into public.product_prices (product_id, label, price, sort_order) values
      (prod_id, '0.5 kg', 500, 1),
      (prod_id, '1 kg', 1000, 2),
      (prod_id, '1.5 kg', 1500, 3),
      (prod_id, '2 kg', 2000, 4);

    insert into public.product_images (product_id, url, sort_order) values
      (prod_id, 'https://placehold.co/800x800/FF6B6B/FFFFFF?text=Birthday+Cake', 1);
  end if;

  if not exists (select 1 from public.products where name_en = 'Chocolate Drip Birthday Cake') then
    insert into public.products (
      category_id, name_en, name_am, description_en, description_am, is_available,
      require_message, require_schedule_date, require_advance_payment, minimum_notice_days, sort_order
    ) values (
      cat_cake_id, 'Chocolate Drip Birthday Cake', 'የቸኮሌት ድሪፕ የልደት ኬክ',
      'Rich chocolate sponge with a glossy chocolate drip and fresh decoration.',
      'ጥቅጥቅ ያለ የቸኮሌት ኬክ ከቸኮሌት ድሪፕ እና ከአዲስ ጌጣጌጥ ጋር።',
      true, true, true, true, 1, 2
    ) returning id into prod_id;

    insert into public.product_prices (product_id, label, price, sort_order) values
      (prod_id, '1 kg', 1300, 1),
      (prod_id, '1.5 kg', 1900, 2),
      (prod_id, '2 kg', 2500, 3);

    insert into public.product_images (product_id, url, sort_order) values
      (prod_id, 'https://placehold.co/800x800/8C2828/FFFFFF?text=Chocolate+Cake', 1);
  end if;

  -- ---------------------------------------------------------------------
  -- Burger products (no special rules)
  -- ---------------------------------------------------------------------
  if not exists (select 1 from public.products where name_en = 'Classic Beef Burger') then
    insert into public.products (
      category_id, name_en, name_am, description_en, description_am, is_available,
      require_message, require_schedule_date, require_advance_payment, minimum_notice_days, sort_order
    ) values (
      cat_burger_id, 'Classic Beef Burger', 'ክላሲክ የበሬ በርገር',
      'Grilled beef patty, cheddar, lettuce, tomato and our special sauce in a soft bun.',
      'የተጠበሰ የበሬ ስጋ ከቼዳር አይብ፣ ሰላጣ፣ ቲማቲም እና ልዩ ሶስ ጋር።',
      true, false, false, false, 0, 1
    ) returning id into prod_id;

    insert into public.product_prices (product_id, label, price, sort_order) values
      (prod_id, 'Regular', 250, 1),
      (prod_id, 'Double', 380, 2);

    insert into public.product_images (product_id, url, sort_order) values
      (prod_id, 'https://placehold.co/800x800/2D3748/FFFFFF?text=Beef+Burger', 1);
  end if;

  if not exists (select 1 from public.products where name_en = 'Spicy Chicken Burger') then
    insert into public.products (
      category_id, name_en, name_am, description_en, description_am, is_available,
      require_message, require_schedule_date, require_advance_payment, minimum_notice_days, sort_order
    ) values (
      cat_burger_id, 'Spicy Chicken Burger', 'ስፓይሲ የዶሮ በርገር',
      'Crispy fried chicken fillet with spicy mayo, pickles and fresh lettuce.',
      'ክሪስፒ የተጠበሰ ዶሮ ከስፓይሲ ማዮ እና ከትኩስ ሰላጣ ጋር።',
      true, false, false, false, 0, 2
    ) returning id into prod_id;

    insert into public.product_prices (product_id, label, price, sort_order) values
      (prod_id, 'Regular', 270, 1);

    insert into public.product_images (product_id, url, sort_order) values
      (prod_id, 'https://placehold.co/800x800/F0504F/FFFFFF?text=Chicken+Burger', 1);
  end if;

  -- ---------------------------------------------------------------------
  -- Chocolate products (no special rules)
  -- ---------------------------------------------------------------------
  if not exists (select 1 from public.products where name_en = 'Assorted Chocolate Box') then
    insert into public.products (
      category_id, name_en, name_am, description_en, description_am, is_available,
      require_message, require_schedule_date, require_advance_payment, minimum_notice_days, sort_order
    ) values (
      cat_choco_id, 'Assorted Chocolate Box', 'የተለያዩ ቸኮሌት ሳጥን',
      'A gift box of handcrafted milk, dark and white chocolate pieces.',
      'የእጅ ስራ የወተት፣ ጥቁር እና ነጭ ቸኮሌት ስብስብ ለስጦታ።',
      true, false, false, false, 0, 1
    ) returning id into prod_id;

    insert into public.product_prices (product_id, label, price, sort_order) values
      (prod_id, 'Small Box (9 pcs)', 450, 1),
      (prod_id, 'Large Box (16 pcs)', 750, 2);

    insert into public.product_images (product_id, url, sort_order) values
      (prod_id, 'https://placehold.co/800x800/FFA8A8/2D3748?text=Chocolate+Box', 1);
  end if;

  if not exists (select 1 from public.products where name_en = 'Dark Chocolate Bar') then
    insert into public.products (
      category_id, name_en, name_am, description_en, description_am, is_available,
      require_message, require_schedule_date, require_advance_payment, minimum_notice_days, sort_order
    ) values (
      cat_choco_id, 'Dark Chocolate Bar', 'ጥቁር ቸኮሌት ባር',
      '70% single-origin dark chocolate bar.',
      '70% ጥቁር ቸኮሌት ባር።',
      true, false, false, false, 0, 2
    ) returning id into prod_id;

    insert into public.product_prices (product_id, label, price, sort_order) values
      (prod_id, '100g', 180, 1);

    insert into public.product_images (product_id, url, sort_order) values
      (prod_id, 'https://placehold.co/800x800/8C2828/FFFFFF?text=Dark+Chocolate', 1);
  end if;

  -- ---------------------------------------------------------------------
  -- Default store settings
  -- ---------------------------------------------------------------------
  insert into public.settings (key, value) values
    ('cod_enabled', 'true'),
    ('telebirr_enabled', 'true'),
    ('cbe_enabled', 'true'),
    ('telebirr_number', ''),
    ('cbe_number', '')
  on conflict (key) do nothing;

end $$;
