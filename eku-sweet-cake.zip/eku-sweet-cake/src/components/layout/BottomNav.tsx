"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { Home, Grid3X3, ShoppingCart } from "lucide-react";
import { useCartStore } from "@/store/cart";
import { getTranslations } from "@/lib/i18n/translations";
import { cn } from "@/lib/utils";

export function BottomNav() {
  const { itemCount, locale } = useCartStore();
  const t = getTranslations(locale);
  const pathname = usePathname();
  const count = itemCount();

  const links = [
    { href: "/", label: t.home, icon: Home },
    { href: "/categories", label: t.categories, icon: Grid3X3 },
    { href: "/cart", label: t.cart, icon: ShoppingCart, badge: count },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 flex items-center justify-around border-t border-accent-200/50 bg-white/95 pb-safe backdrop-blur-md sm:hidden safe-bottom">
      {links.map((link) => {
        const active = pathname === link.href;
        return (
          <Link
            key={link.href}
            href={link.href}
            className={cn(
              "relative flex flex-1 flex-col items-center gap-0.5 py-3 transition-colors",
              active ? "text-primary" : "text-accent-light"
            )}
          >
            <div className="relative">
              <link.icon size={22} strokeWidth={active ? 2.5 : 1.75} />
              {link.badge && link.badge > 0 && (
                <span className="absolute -right-2 -top-1.5 flex h-4 w-4 items-center justify-center rounded-full bg-primary text-[9px] font-bold text-white">
                  {link.badge > 9 ? "9+" : link.badge}
                </span>
              )}
            </div>
            <span className="text-[10px] font-medium">{link.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}
