"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { categorySchema, type CategoryInput } from "@/lib/validations";
import type { ActionResult, Category } from "@/types/database";

// ── Read ─────────────────────────────────────────────────────────────────────

export async function getCategories(): Promise<Category[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("categories")
    .select("*")
    .order("sort_order", { ascending: true })
    .order("name_en", { ascending: true });

  if (error) {
    console.error("[getCategories]", error.message);
    return [];
  }
  return data ?? [];
}

export async function getActiveCategories(): Promise<Category[]> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("categories")
    .select("*")
    .eq("is_active", true)
    .order("sort_order", { ascending: true });

  if (error) {
    console.error("[getActiveCategories]", error.message);
    return [];
  }
  return data ?? [];
}

export async function getCategoryBySlug(slug: string): Promise<Category | null> {
  const supabase = await createClient();
  const { data, error } = await supabase
    .from("categories")
    .select("*")
    .eq("slug", slug)
    .eq("is_active", true)
    .single();

  if (error) return null;
  return data;
}

// ── Create ────────────────────────────────────────────────────────────────────

export async function createCategory(
  input: CategoryInput
): Promise<ActionResult<Category>> {
  const parsed = categorySchema.safeParse(input);
  if (!parsed.success) {
    return { success: false, error: parsed.error.errors[0]?.message ?? "Validation failed." };
  }

  const supabase = await createClient();
  const { data, error } = await supabase
    .from("categories")
    .insert({
      name_en: parsed.data.nameEn,
      name_am: parsed.data.nameAm,
      slug: parsed.data.slug,
      description_en: parsed.data.descriptionEn,
      description_am: parsed.data.descriptionAm,
      sort_order: parsed.data.sortOrder,
      is_active: parsed.data.isActive,
    })
    .select()
    .single();

  if (error) {
    if (error.code === "23505") {
      return { success: false, error: "A category with this slug already exists." };
    }
    return { success: false, error: error.message };
  }

  revalidatePath("/admin/categories");
  revalidatePath("/categories");
  revalidatePath("/");
  return { success: true, data };
}

// ── Update ────────────────────────────────────────────────────────────────────

export async function updateCategory(
  id: string,
  input: CategoryInput
): Promise<ActionResult<Category>> {
  const parsed = categorySchema.safeParse(input);
  if (!parsed.success) {
    return { success: false, error: parsed.error.errors[0]?.message ?? "Validation failed." };
  }

  const supabase = await createClient();
  const { data, error } = await supabase
    .from("categories")
    .update({
      name_en: parsed.data.nameEn,
      name_am: parsed.data.nameAm,
      slug: parsed.data.slug,
      description_en: parsed.data.descriptionEn,
      description_am: parsed.data.descriptionAm,
      sort_order: parsed.data.sortOrder,
      is_active: parsed.data.isActive,
    })
    .eq("id", id)
    .select()
    .single();

  if (error) {
    if (error.code === "23505") {
      return { success: false, error: "A category with this slug already exists." };
    }
    return { success: false, error: error.message };
  }

  revalidatePath("/admin/categories");
  revalidatePath("/categories");
  revalidatePath("/");
  return { success: true, data };
}

// ── Delete ────────────────────────────────────────────────────────────────────

export async function deleteCategory(id: string): Promise<ActionResult> {
  const supabase = await createClient();
  const { error } = await supabase.from("categories").delete().eq("id", id);

  if (error) {
    if (error.code === "23503") {
      return {
        success: false,
        error: "Cannot delete — this category still has products. Remove them first.",
      };
    }
    return { success: false, error: error.message };
  }

  revalidatePath("/admin/categories");
  revalidatePath("/categories");
  revalidatePath("/");
  return { success: true, data: undefined };
}
