"use client";

import Link from "next/link";
import Image from "next/image";
import { Trash2, Plus, Minus, ShoppingBag } from "lucide-react";
import { useCartStore } from "@/store/cart";
import { getTranslations } from "@/lib/i18n/translations";
import { formatCurrency } from "@/lib/utils";

export default function CartPage() {
  const { items, locale, removeItem, updateQuantity, subtotal } = useCartStore();
  const t = getTranslations(locale);

  if (items.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center px-4 py-24 text-center">
        <div className="mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-secondary text-4xl">
          🛒
        </div>
        <h2 className="mb-2 text-xl font-bold text-accent">{t.cartEmpty}</h2>
        <p className="mb-6 text-sm text-accent-light">{t.cartEmptyHint}</p>
        <Link href="/categories" className="btn-primary">
          <ShoppingBag size={16} />
          {t.browseMenu}
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-8">
      <h1 className="mb-6 text-2xl font-bold text-accent">{t.myCart}</h1>

      <div className="flex flex-col gap-3">
        {items.map((item) => (
          <div key={item.id} className="card flex gap-3 p-4">
            {/* Image */}
            <div className="relative h-20 w-20 flex-shrink-0 overflow-hidden rounded-2xl bg-secondary">
              {item.image ? (
                <Image src={item.image} alt={item.nameEn} fill className="object-cover" />
              ) : (
                <div className="flex h-full items-center justify-center text-2xl">🎂</div>
              )}
            </div>

            {/* Info */}
            <div className="flex flex-1 flex-col gap-1">
              <p className="text-sm font-bold text-accent line-clamp-2">
                {locale === "am" ? item.nameAm : item.nameEn}
              </p>
              {item.priceLabel && (
                <p className="text-xs text-accent-light">{item.priceLabel}</p>
              )}
              {item.cakeMessage && (
                <p className="text-xs text-accent-light">✏️ {item.cakeMessage}</p>
              )}
              {item.scheduleDate && (
                <p className="text-xs text-accent-light">📅 {item.scheduleDate}</p>
              )}
              <p className="text-sm font-bold text-primary">
                {formatCurrency(item.unitPrice * item.quantity)}
              </p>

              {/* Quantity + remove */}
              <div className="mt-1 flex items-center gap-3">
                <div className="flex items-center rounded-xl border border-accent-200 bg-white">
                  <button
                    onClick={() => updateQuantity(item.id, item.quantity - 1)}
                    className="flex h-8 w-8 items-center justify-center rounded-l-xl text-accent transition hover:bg-secondary"
                    aria-label="Decrease quantity"
                  >
                    <Minus size={14} />
                  </button>
                  <span className="w-8 text-center text-sm font-semibold text-accent">
                    {item.quantity}
                  </span>
                  <button
                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                    className="flex h-8 w-8 items-center justify-center rounded-r-xl text-accent transition hover:bg-secondary"
                    aria-label="Increase quantity"
                  >
                    <Plus size={14} />
                  </button>
                </div>

                <button
                  onClick={() => removeItem(item.id)}
                  className="ml-auto text-red-400 hover:text-red-600 transition"
                  aria-label={t.remove}
                >
                  <Trash2 size={16} />
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Summary */}
      <div className="mt-6 card p-5">
        <div className="flex items-center justify-between text-sm text-accent-light mb-2">
          <span>{t.subtotal}</span>
          <span>{formatCurrency(subtotal())}</span>
        </div>
        <div className="flex items-center justify-between text-sm text-accent-light mb-3">
          <span>{t.delivery}</span>
          <span className="text-green-600 font-medium">{t.free}</span>
        </div>
        <div className="border-t border-accent-200 pt-3 flex items-center justify-between font-bold text-accent">
          <span>{t.total}</span>
          <span className="text-primary text-lg">{formatCurrency(subtotal())}</span>
        </div>

        <Link href="/checkout" className="btn-primary mt-5 w-full py-4 text-base">
          {t.proceedToCheckout}
        </Link>
        <p className="mt-3 text-center text-xs text-accent-light">{t.freeDeliveryNote}</p>
      </div>
    </div>
  );
}
