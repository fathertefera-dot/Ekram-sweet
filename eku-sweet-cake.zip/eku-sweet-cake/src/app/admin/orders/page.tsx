"use client";

import { useState, useEffect, useCallback } from "react";
import { ChevronDown } from "lucide-react";
import { getOrders, updateOrderStatus } from "@/actions/orders";
import { formatCurrency, formatDateTime } from "@/lib/utils";
import type { Order, OrderItem, OrderStatus } from "@/types/database";

const STATUS_LABELS: Record<OrderStatus, string> = {
  pending: "Pending",
  confirmed: "Confirmed",
  preparing: "Preparing",
  out_for_delivery: "Out for Delivery",
  delivered: "Delivered",
  cancelled: "Cancelled",
};

const PAYMENT_LABELS: Record<string, string> = {
  cod: "Cash on Delivery",
  telebirr: "Telebirr",
  cbe_birr: "CBE Birr",
};

const ALL_STATUSES: OrderStatus[] = [
  "pending", "confirmed", "preparing", "out_for_delivery", "delivered", "cancelled",
];

type OrderWithItems = Order & { items: OrderItem[] };

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<OrderWithItems[]>([]);
  const [filter, setFilter] = useState<OrderStatus | "all">("all");
  const [expanded, setExpanded] = useState<string | null>(null);
  const [updating, setUpdating] = useState<string | null>(null);

  const load = useCallback(async () => {
    const data = await getOrders();
    setOrders(data as OrderWithItems[]);
  }, []);

  useEffect(() => { load(); }, [load]);

  async function handleStatusChange(orderId: string, status: OrderStatus) {
    setUpdating(orderId);
    await updateOrderStatus(orderId, status);
    setUpdating(null);
    await load();
  }

  const filtered = filter === "all" ? orders : orders.filter((o) => o.status === filter);

  return (
    <div className="p-6">
      <div className="mb-6 flex items-center justify-between flex-wrap gap-3">
        <h1 className="text-2xl font-bold text-accent">Orders</h1>
        <div className="flex items-center gap-2 flex-wrap">
          {(["all", ...ALL_STATUSES] as const).map((s) => (
            <button
              key={s}
              onClick={() => setFilter(s)}
              className={`rounded-xl px-3 py-1.5 text-xs font-semibold transition-colors ${
                filter === s
                  ? "bg-primary text-white"
                  : "bg-white border border-accent-200 text-accent-light hover:text-accent"
              }`}
            >
              {s === "all" ? "All" : STATUS_LABELS[s]}
            </button>
          ))}
        </div>
      </div>

      {filtered.length === 0 ? (
        <div className="card flex flex-col items-center justify-center py-16 text-center">
          <span className="mb-3 text-4xl">🧾</span>
          <p className="text-accent-light text-sm">No orders found.</p>
        </div>
      ) : (
        <div className="flex flex-col gap-3">
          {filtered.map((order) => (
            <div key={order.id} className="card overflow-hidden">
              {/* Header row */}
              <button
                className="w-full flex items-center justify-between p-4 hover:bg-accent-50 transition-colors"
                onClick={() => setExpanded(expanded === order.id ? null : order.id)}
              >
                <div className="flex items-center gap-3 text-left">
                  <span className="font-bold text-primary text-sm">#{order.order_number}</span>
                  <div>
                    <p className="font-medium text-accent text-sm">{order.customer_name}</p>
                    <p className="text-xs text-accent-light">{formatDateTime(order.created_at)}</p>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`badge status-${order.status}`}>
                    {STATUS_LABELS[order.status]}
                  </span>
                  <span className="font-bold text-accent text-sm hidden sm:block">
                    {formatCurrency(order.total)}
                  </span>
                  <ChevronDown
                    size={16}
                    className={`text-accent-light transition-transform ${expanded === order.id ? "rotate-180" : ""}`}
                  />
                </div>
              </button>

              {/* Expanded detail */}
              {expanded === order.id && (
                <div className="border-t border-accent-200 p-4">
                  <div className="grid gap-4 sm:grid-cols-2">
                    {/* Customer info */}
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wider text-accent-light mb-2">Customer</p>
                      <p className="text-sm text-accent">{order.customer_name}</p>
                      <p className="text-sm text-accent-light">{order.customer_phone}</p>
                      <p className="text-sm text-accent-light mt-1">{order.delivery_address}</p>
                      {order.additional_note && (
                        <p className="mt-1 text-xs text-accent-light italic">Note: {order.additional_note}</p>
                      )}
                    </div>

                    {/* Items */}
                    <div>
                      <p className="text-xs font-semibold uppercase tracking-wider text-accent-light mb-2">Items</p>
                      {order.items.map((item) => (
                        <div key={item.id} className="mb-2">
                          <p className="text-sm font-medium text-accent">
                            {item.product_name_en}
                            {item.price_label ? ` (${item.price_label})` : ""}
                            <span className="font-normal text-accent-light"> ×{item.quantity}</span>
                          </p>
                          {item.cake_message && <p className="text-xs text-accent-light ml-2">✏️ {item.cake_message}</p>}
                          {item.schedule_date && <p className="text-xs text-accent-light ml-2">📅 {item.schedule_date}</p>}
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Payment + total */}
                  <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-accent-200 pt-4">
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-accent-light">Payment:</span>
                      <span className="text-xs font-semibold text-accent">{PAYMENT_LABELS[order.payment_method]}</span>
                      <span className="text-xs font-bold text-primary ml-4">{formatCurrency(order.total)}</span>
                    </div>

                    {/* Status update */}
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-accent-light">Update status:</span>
                      <select
                        value={order.status}
                        disabled={updating === order.id}
                        onChange={(e) => handleStatusChange(order.id, e.target.value as OrderStatus)}
                        className="rounded-xl border border-accent-200 bg-white px-3 py-1.5 text-xs font-medium text-accent outline-none focus:border-primary"
                      >
                        {ALL_STATUSES.map((s) => (
                          <option key={s} value={s}>{STATUS_LABELS[s]}</option>
                        ))}
                      </select>
                      {updating === order.id && <span className="text-xs text-accent-light animate-pulse">Updating…</span>}
                    </div>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
