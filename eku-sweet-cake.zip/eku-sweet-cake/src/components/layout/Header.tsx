"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { ShoppingCart, Home, Grid3X3, Globe } from "lucide-react";
import { useCartStore } from "@/store/cart";
import { getTranslations } from "@/lib/i18n/translations";
import { cn } from "@/lib/utils";

export function Header() {
  const { itemCount, locale, setLocale } = useCartStore();
  const t = getTranslations(locale);
  const pathname = usePathname();
  const count = itemCount();

  const navLinks = [
    { href: "/", label: t.home, icon: Home },
    { href: "/categories", label: t.categories, icon: Grid3X3 },
  ];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-accent-200/50 bg-white/90 backdrop-blur-md">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
        {/* Logo */}
        <Link href="/" className="flex items-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary">
            <span className="text-lg font-bold text-white">E</span>
          </div>
          <div className="hidden sm:block">
            <span className="text-base font-bold text-accent">Eku</span>
            <span className="ml-1 text-base font-bold text-primary">Sweet Cake</span>
          </div>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden sm:flex items-center gap-1">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className={cn(
                "flex items-center gap-1.5 rounded-xl px-3 py-2 text-sm font-medium transition-colors",
                pathname === link.href
                  ? "bg-secondary text-primary"
                  : "text-accent-light hover:bg-secondary hover:text-accent"
              )}
            >
              <link.icon size={15} />
              {link.label}
            </Link>
          ))}
        </nav>

        {/* Right: Language + Cart */}
        <div className="flex items-center gap-2">
          {/* Language toggle */}
          <button
            onClick={() => setLocale(locale === "en" ? "am" : "en")}
            className="flex items-center gap-1.5 rounded-xl border border-accent-200 bg-white px-3 py-2 text-xs font-semibold text-accent transition-colors hover:bg-secondary"
            aria-label="Toggle language"
          >
            <Globe size={14} />
            {locale === "en" ? "አማርኛ" : "English"}
          </button>

          {/* Cart */}
          <Link
            href="/cart"
            className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-white transition-all hover:bg-primary-600 active:scale-95"
            aria-label={`${t.cart} (${count})`}
          >
            <ShoppingCart size={18} />
            {count > 0 && (
              <span className="absolute -right-1 -top-1 flex h-5 w-5 items-center justify-center rounded-full bg-accent text-[10px] font-bold text-white">
                {count > 99 ? "99+" : count}
              </span>
            )}
          </Link>
        </div>
      </div>
    </header>
  );
}
