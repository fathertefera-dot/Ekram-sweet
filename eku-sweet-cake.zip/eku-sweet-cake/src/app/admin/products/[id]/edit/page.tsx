import { notFound } from "next/navigation";
import { getProductById } from "@/actions/products";
import { getCategories } from "@/actions/categories";
import { ProductForm } from "@/components/admin/ProductForm";

interface Props {
  params: Promise<{ id: string }>;
}

export default async function EditProductPage({ params }: Props) {
  const { id } = await params;
  const [product, categories] = await Promise.all([
    getProductById(id),
    getCategories(),
  ]);

  if (!product) notFound();

  return (
    <div className="p-6">
      <h1 className="mb-6 text-2xl font-bold text-accent">Edit Product</h1>
      <ProductForm categories={categories} product={product} />
    </div>
  );
}
