"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";
import { generateId } from "@/lib/utils";
import type { CartItem, Locale } from "@/types/database";

interface CartStore {
  items: CartItem[];
  locale: Locale;

  // ── Actions ───────────────────────────────────────────────────────────
  addItem: (item: Omit<CartItem, "id">) => void;
  removeItem: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  updateCustomisation: (
    id: string,
    data: { cakeMessage?: string; scheduleDate?: string }
  ) => void;
  clearCart: () => void;
  setLocale: (locale: Locale) => void;

  // ── Derived ───────────────────────────────────────────────────────────
  itemCount: () => number;
  subtotal: () => number;
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      locale: "en",

      addItem(item) {
        const existing = get().items.find(
          (i) =>
            i.productId === item.productId &&
            i.priceOptionId === item.priceOptionId &&
            !item.requireMessage &&
            !item.requireScheduleDate
        );

        if (existing) {
          set((s) => ({
            items: s.items.map((i) =>
              i.id === existing.id
                ? { ...i, quantity: i.quantity + item.quantity }
                : i
            ),
          }));
        } else {
          set((s) => ({
            items: [...s.items, { ...item, id: generateId() }],
          }));
        }
      },

      removeItem(id) {
        set((s) => ({ items: s.items.filter((i) => i.id !== id) }));
      },

      updateQuantity(id, quantity) {
        if (quantity < 1) {
          get().removeItem(id);
          return;
        }
        set((s) => ({
          items: s.items.map((i) => (i.id === id ? { ...i, quantity } : i)),
        }));
      },

      updateCustomisation(id, data) {
        set((s) => ({
          items: s.items.map((i) => (i.id === id ? { ...i, ...data } : i)),
        }));
      },

      clearCart() {
        set({ items: [] });
      },

      setLocale(locale) {
        set({ locale });
      },

      itemCount() {
        return get().items.reduce((sum, i) => sum + i.quantity, 0);
      },

      subtotal() {
        return get().items.reduce(
          (sum, i) => sum + i.unitPrice * i.quantity,
          0
        );
      },
    }),
    {
      name: "eku-cart",
      partialize: (state) => ({ items: state.items, locale: state.locale }),
    }
  )
);
