import Link from "next/link";
import { LayoutDashboard, Tag, Package, ShoppingBag, Settings, LogOut } from "lucide-react";
import { getAdminUser } from "@/actions/settings";
import { adminSignOut } from "@/actions/settings";

const navLinks = [
  { href: "/admin/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { href: "/admin/categories", label: "Categories", icon: Tag },
  { href: "/admin/products", label: "Products", icon: Package },
  { href: "/admin/orders", label: "Orders", icon: ShoppingBag },
  { href: "/admin/settings", label: "Settings", icon: Settings },
];

export default async function AdminLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const user = await getAdminUser();

  return (
    <div className="flex min-h-screen bg-accent-50">
      {/* Sidebar */}
      <aside className="hidden lg:flex w-60 flex-col border-r border-accent-200 bg-white">
        {/* Logo */}
        <div className="flex h-16 items-center gap-2 px-5 border-b border-accent-200">
          <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-primary">
            <span className="text-sm font-bold text-white">E</span>
          </div>
          <div>
            <span className="text-sm font-bold text-accent">Eku</span>
            <span className="ml-1 text-xs text-accent-light">Admin</span>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex flex-col gap-1 p-3 flex-1">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-sm font-medium text-accent-light transition-colors hover:bg-secondary hover:text-accent"
            >
              <link.icon size={16} />
              {link.label}
            </Link>
          ))}
        </nav>

        {/* User */}
        <div className="border-t border-accent-200 p-4">
          <p className="text-xs text-accent-light truncate">{user?.email}</p>
          <form action={adminSignOut}>
            <button type="submit" className="mt-2 flex items-center gap-2 text-xs text-red-500 hover:text-red-700">
              <LogOut size={14} /> Sign Out
            </button>
          </form>
        </div>
      </aside>

      {/* Mobile top bar */}
      <div className="fixed top-0 left-0 right-0 z-40 flex lg:hidden h-14 items-center justify-between border-b border-accent-200 bg-white px-4">
        <Link href="/admin/dashboard" className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-primary">
            <span className="text-xs font-bold text-white">E</span>
          </div>
          <span className="text-sm font-bold text-accent">Admin</span>
        </Link>
        <nav className="flex items-center gap-1">
          {navLinks.map((link) => (
            <Link key={link.href} href={link.href} title={link.label}
              className="flex h-9 w-9 items-center justify-center rounded-xl text-accent-light hover:bg-secondary hover:text-accent transition-colors">
              <link.icon size={18} />
            </Link>
          ))}
        </nav>
      </div>

      {/* Main */}
      <main className="flex-1 pt-14 lg:pt-0 overflow-auto">
        {children}
      </main>
    </div>
  );
}
