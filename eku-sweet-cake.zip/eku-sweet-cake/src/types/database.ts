// =============================================================================
// Database types
// -----------------------------------------------------------------------
// Hand-written to mirror the SQL in supabase/migrations exactly. If you
// change the schema, update this file (or regenerate with
// `supabase gen types typescript` and merge in the app-level types below).
// =============================================================================

export type PaymentMethod = "cod" | "telebirr" | "cbe_birr";

export type OrderStatus =
  | "pending"
  | "confirmed"
  | "preparing"
  | "out_for_delivery"
  | "delivered"
  | "cancelled";

export const ORDER_STATUSES: OrderStatus[] = [
  "pending",
  "confirmed",
  "preparing",
  "out_for_delivery",
  "delivered",
  "cancelled",
];

export const PAYMENT_METHODS: PaymentMethod[] = ["cod", "telebirr", "cbe_birr"];

export interface Database {
  public: {
    Tables: {
      admins: {
        Row: {
          id: string;
          full_name: string;
          email: string;
          created_at: string;
        };
        Insert: {
          id: string;
          full_name?: string;
          email: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          full_name?: string;
          email?: string;
          created_at?: string;
        };
      };
      categories: {
        Row: {
          id: string;
          name_en: string;
          name_am: string;
          slug: string;
          description_en: string;
          description_am: string;
          image_url: string | null;
          sort_order: number;
          is_active: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name_en: string;
          name_am: string;
          slug: string;
          description_en?: string;
          description_am?: string;
          image_url?: string | null;
          sort_order?: number;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          name_en?: string;
          name_am?: string;
          slug?: string;
          description_en?: string;
          description_am?: string;
          image_url?: string | null;
          sort_order?: number;
          is_active?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      products: {
        Row: {
          id: string;
          category_id: string;
          name_en: string;
          name_am: string;
          description_en: string;
          description_am: string;
          is_available: boolean;
          require_message: boolean;
          require_schedule_date: boolean;
          require_advance_payment: boolean;
          minimum_notice_days: number;
          sort_order: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          category_id: string;
          name_en: string;
          name_am: string;
          description_en?: string;
          description_am?: string;
          is_available?: boolean;
          require_message?: boolean;
          require_schedule_date?: boolean;
          require_advance_payment?: boolean;
          minimum_notice_days?: number;
          sort_order?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          category_id?: string;
          name_en?: string;
          name_am?: string;
          description_en?: string;
          description_am?: string;
          is_available?: boolean;
          require_message?: boolean;
          require_schedule_date?: boolean;
          require_advance_payment?: boolean;
          minimum_notice_days?: number;
          sort_order?: number;
          created_at?: string;
          updated_at?: string;
        };
      };
      product_images: {
        Row: {
          id: string;
          product_id: string;
          url: string;
          sort_order: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          product_id: string;
          url: string;
          sort_order?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          product_id?: string;
          url?: string;
          sort_order?: number;
          created_at?: string;
        };
      };
      product_prices: {
        Row: {
          id: string;
          product_id: string;
          label: string;
          price: number;
          sort_order: number;
          created_at: string;
        };
        Insert: {
          id?: string;
          product_id: string;
          label?: string;
          price: number;
          sort_order?: number;
          created_at?: string;
        };
        Update: {
          id?: string;
          product_id?: string;
          label?: string;
          price?: number;
          sort_order?: number;
          created_at?: string;
        };
      };
      orders: {
        Row: {
          id: string;
          order_number: number;
          customer_name: string;
          customer_phone: string;
          delivery_address: string;
          additional_note: string;
          payment_method: PaymentMethod;
          status: OrderStatus;
          subtotal: number;
          total: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          order_number?: number;
          customer_name: string;
          customer_phone: string;
          delivery_address: string;
          additional_note?: string;
          payment_method: PaymentMethod;
          status?: OrderStatus;
          subtotal: number;
          total: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          order_number?: number;
          customer_name?: string;
          customer_phone?: string;
          delivery_address?: string;
          additional_note?: string;
          payment_method?: PaymentMethod;
          status?: OrderStatus;
          subtotal?: number;
          total?: number;
          created_at?: string;
          updated_at?: string;
        };
      };
      order_items: {
        Row: {
          id: string;
          order_id: string;
          product_id: string | null;
          product_name_en: string;
          product_name_am: string;
          price_label: string;
          unit_price: number;
          quantity: number;
          line_total: number;
          cake_message: string | null;
          schedule_date: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          order_id: string;
          product_id?: string | null;
          product_name_en: string;
          product_name_am: string;
          price_label?: string;
          unit_price: number;
          quantity?: number;
          line_total: number;
          cake_message?: string | null;
          schedule_date?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          order_id?: string;
          product_id?: string | null;
          product_name_en?: string;
          product_name_am?: string;
          price_label?: string;
          unit_price?: number;
          quantity?: number;
          line_total?: number;
          cake_message?: string | null;
          schedule_date?: string | null;
          created_at?: string;
        };
      };
      settings: {
        Row: {
          key: string;
          value: string;
          updated_at: string;
        };
        Insert: {
          key: string;
          value?: string;
          updated_at?: string;
        };
        Update: {
          key?: string;
          value?: string;
          updated_at?: string;
        };
      };
    };
  };
}

// =============================================================================
// Convenience row aliases
// =============================================================================
export type Admin = Database["public"]["Tables"]["admins"]["Row"];
export type Category = Database["public"]["Tables"]["categories"]["Row"];
export type Product = Database["public"]["Tables"]["products"]["Row"];
export type ProductImage = Database["public"]["Tables"]["product_images"]["Row"];
export type ProductPrice = Database["public"]["Tables"]["product_prices"]["Row"];
export type Order = Database["public"]["Tables"]["orders"]["Row"];
export type OrderItem = Database["public"]["Tables"]["order_items"]["Row"];
export type Setting = Database["public"]["Tables"]["settings"]["Row"];

export type CategoryInsert = Database["public"]["Tables"]["categories"]["Insert"];
export type CategoryUpdate = Database["public"]["Tables"]["categories"]["Update"];
export type ProductInsert = Database["public"]["Tables"]["products"]["Insert"];
export type ProductUpdate = Database["public"]["Tables"]["products"]["Update"];

// =============================================================================
// App-level domain types
// =============================================================================

export type Locale = "en" | "am";
export const LOCALES: Locale[] = ["en", "am"];
export const DEFAULT_LOCALE: Locale = "en";

/** Product joined with its images and price options (used across the storefront). */
export interface ProductWithRelations extends Product {
  category?: Category | null;
  images: ProductImage[];
  prices: ProductPrice[];
}

/** A single line in the shopping cart (persisted client-side). */
export interface CartItem {
  /** Unique id for this cart line (not the product id). */
  id: string;
  productId: string;
  nameEn: string;
  nameAm: string;
  image: string | null;
  priceOptionId: string;
  priceLabel: string;
  unitPrice: number;
  quantity: number;
  /** Snapshot of the product rules at the time it was added to the cart. */
  requireMessage: boolean;
  requireScheduleDate: boolean;
  requireAdvancePayment: boolean;
  minimumNoticeDays: number;
  /** Customer-entered customisation (only used when required by the product). */
  cakeMessage?: string;
  scheduleDate?: string;
}

/** Aggregated numbers shown on the admin dashboard. */
export interface DashboardStats {
  todaysOrders: number;
  pendingOrders: number;
  deliveredOrders: number;
  revenueToday: number;
  revenueThisMonth: number;
}

/** Payment availability resolved from store settings (used at checkout). */
export interface PaymentSettings {
  codEnabled: boolean;
  telebirrEnabled: boolean;
  cbeEnabled: boolean;
  telebirrNumber: string;
  cbeNumber: string;
}

/** Generic result type returned by Server Actions. */
export type ActionResult<T = undefined> =
  | { success: true; data: T }
  | { success: false; error: string };
