#!/usr/bin/env node
/**
 * Eku Sweet Cake — PWA Icon Generator
 *
 * Generates simple SVG-based placeholder icons in all required sizes.
 * In production, replace these with professionally designed PNG icons.
 *
 * Usage (from project root):
 *   node scripts/generate-icons.js
 *
 * Requires: npm install canvas (or use a design tool like Figma / Adobe Illustrator)
 *
 * Quick alternative — generate icons online:
 *   1. Go to https://realfavicongenerator.net or https://pwa-asset-generator.com
 *   2. Upload a 512×512 PNG of your logo
 *   3. Download the icon pack and put PNGs in /public/icons/
 */

const fs = require("fs");
const path = require("path");

const SIZES = [72, 96, 128, 144, 152, 192, 384, 512];
const OUT_DIR = path.join(__dirname, "../public/icons");

if (!fs.existsSync(OUT_DIR)) fs.mkdirSync(OUT_DIR, { recursive: true });

for (const size of SIZES) {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
  <rect width="${size}" height="${size}" rx="${size * 0.2}" fill="#FF6B6B"/>
  <text x="50%" y="54%" dominant-baseline="middle" text-anchor="middle"
    font-family="-apple-system, sans-serif" font-weight="700"
    font-size="${size * 0.5}" fill="white">E</text>
</svg>`;
  fs.writeFileSync(path.join(OUT_DIR, `icon-${size}x${size}.svg`), svg);
  console.log(`✓ icon-${size}x${size}.svg`);
}

// apple-touch-icon
const apple = `<svg xmlns="http://www.w3.org/2000/svg" width="180" height="180" viewBox="0 0 180 180">
  <rect width="180" height="180" rx="36" fill="#FF6B6B"/>
  <text x="50%" y="54%" dominant-baseline="middle" text-anchor="middle"
    font-family="-apple-system, sans-serif" font-weight="700"
    font-size="90" fill="white">E</text>
</svg>`;
fs.writeFileSync(path.join(OUT_DIR, "apple-touch-icon.svg"), apple);
console.log("✓ apple-touch-icon.svg");

console.log("\n⚠️  These are SVG placeholders. For a production app, convert them");
console.log("   to PNG using a tool like Sharp or an online favicon generator.");
