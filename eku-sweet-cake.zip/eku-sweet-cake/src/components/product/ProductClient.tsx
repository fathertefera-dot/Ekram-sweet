"use client";

import { useState } from "react";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { ShoppingCart, ChevronLeft, ChevronRight } from "lucide-react";
import { useCartStore } from "@/store/cart";
import { getTranslations } from "@/lib/i18n/translations";
import { formatCurrency, minDeliveryDate } from "@/lib/utils";
import { cn } from "@/lib/utils";
import type { ProductWithRelations } from "@/types/database";

interface ProductClientProps {
  product: ProductWithRelations;
}

export function ProductClient({ product }: ProductClientProps) {
  const { locale, addItem } = useCartStore();
  const t = getTranslations(locale);
  const router = useRouter();

  const images = product.images ?? [];
  const prices = (product.prices ?? []).sort((a, b) => a.sort_order - b.sort_order);

  const [imgIndex, setImgIndex] = useState(0);
  const [selectedPriceId, setSelectedPriceId] = useState<string>("");
  const [cakeMessage, setCakeMessage] = useState("");
  const [scheduleDate, setScheduleDate] = useState("");
  const [error, setError] = useState("");
  const [added, setAdded] = useState(false);

  const selectedPrice = prices.find((p) => p.id === selectedPriceId);
  const name = locale === "am" ? product.name_am : product.name_en;
  const description = locale === "am" ? product.description_am : product.description_en;

  function handleAddToCart() {
    setError("");

    if (!selectedPrice) {
      setError(t.validationPriceOption);
      return;
    }
    if (product.require_message && !cakeMessage.trim()) {
      setError(t.validationCakeMessage);
      return;
    }
    if (product.require_schedule_date && !scheduleDate) {
      setError(t.validationDate);
      return;
    }

    addItem({
      productId: product.id,
      nameEn: product.name_en,
      nameAm: product.name_am,
      image: images[0]?.url ?? null,
      priceOptionId: selectedPrice.id,
      priceLabel: selectedPrice.label,
      unitPrice: selectedPrice.price,
      quantity: 1,
      requireMessage: product.require_message,
      requireScheduleDate: product.require_schedule_date,
      requireAdvancePayment: product.require_advance_payment,
      minimumNoticeDays: product.minimum_notice_days,
      cakeMessage: cakeMessage || undefined,
      scheduleDate: scheduleDate || undefined,
    });

    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-6">
      {/* Back */}
      <button
        onClick={() => router.back()}
        className="mb-4 flex items-center gap-1 text-sm font-medium text-accent-light hover:text-accent"
      >
        <ChevronLeft size={16} /> Back
      </button>

      <div className="grid gap-8 lg:grid-cols-2">
        {/* ── Images ──────────────────────────────────────────────────── */}
        <div>
          <div className="relative aspect-square w-full overflow-hidden rounded-3xl bg-secondary">
            {images.length > 0 ? (
              <Image
                src={images[imgIndex]?.url ?? ""}
                alt={name}
                fill
                className="object-cover"
                sizes="(max-width: 1024px) 100vw, 50vw"
                priority
              />
            ) : (
              <div className="flex h-full items-center justify-center text-6xl">🎂</div>
            )}

            {images.length > 1 && (
              <>
                <button
                  onClick={() => setImgIndex((i) => (i - 1 + images.length) % images.length)}
                  className="absolute left-3 top-1/2 -translate-y-1/2 flex h-9 w-9 items-center justify-center rounded-full bg-white/80 backdrop-blur-sm shadow-md transition hover:bg-white"
                >
                  <ChevronLeft size={18} />
                </button>
                <button
                  onClick={() => setImgIndex((i) => (i + 1) % images.length)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 flex h-9 w-9 items-center justify-center rounded-full bg-white/80 backdrop-blur-sm shadow-md transition hover:bg-white"
                >
                  <ChevronRight size={18} />
                </button>
              </>
            )}
          </div>

          {images.length > 1 && (
            <div className="mt-3 flex gap-2 overflow-x-auto scrollbar-hide">
              {images.map((img, idx) => (
                <button
                  key={img.id}
                  onClick={() => setImgIndex(idx)}
                  className={cn(
                    "relative h-14 w-14 flex-shrink-0 overflow-hidden rounded-xl border-2 transition",
                    idx === imgIndex ? "border-primary" : "border-transparent opacity-60"
                  )}
                >
                  <Image src={img.url} alt="" fill className="object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* ── Details ─────────────────────────────────────────────────── */}
        <div className="flex flex-col gap-5">
          <div>
            <span className="mb-2 inline-block rounded-full bg-secondary px-3 py-0.5 text-xs font-semibold text-primary">
              {locale === "am" ? product.category?.name_am : product.category?.name_en}
            </span>
            <h1 className="text-2xl font-bold text-accent">{name}</h1>
            {description && <p className="mt-2 text-sm text-accent-light leading-relaxed">{description}</p>}
          </div>

          {!product.is_available && (
            <div className="rounded-2xl bg-accent/5 border border-accent-200 px-4 py-3 text-sm font-medium text-accent">
              ⚠️ {t.outOfStock}
            </div>
          )}

          {/* Price options */}
          {prices.length > 0 && (
            <div>
              <label className="field-label">{t.selectPrice}</label>
              <div className="flex flex-wrap gap-2">
                {prices.map((price) => (
                  <button
                    key={price.id}
                    onClick={() => setSelectedPriceId(price.id)}
                    className={cn(
                      "rounded-2xl border-2 px-4 py-2.5 text-sm font-semibold transition-all",
                      selectedPriceId === price.id
                        ? "border-primary bg-primary text-white"
                        : "border-accent-200 bg-white text-accent hover:border-primary/50"
                    )}
                  >
                    {price.label ? `${price.label} — ` : ""}{formatCurrency(price.price)}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Cake message */}
          {product.require_message && (
            <div>
              <label className="field-label">{t.cakeMessage}</label>
              <input
                type="text"
                value={cakeMessage}
                onChange={(e) => setCakeMessage(e.target.value)}
                placeholder={t.cakeMessagePlaceholder}
                maxLength={120}
                className="field-input"
              />
            </div>
          )}

          {/* Schedule date */}
          {product.require_schedule_date && (
            <div>
              <label className="field-label">{t.deliveryDate}</label>
              <input
                type="date"
                value={scheduleDate}
                onChange={(e) => setScheduleDate(e.target.value)}
                min={minDeliveryDate(product.minimum_notice_days)}
                className="field-input"
              />
              <p className="mt-1 text-xs text-accent-light">
                {t.deliveryDateHelp(product.minimum_notice_days)}
              </p>
            </div>
          )}

          {/* Advance payment notice */}
          {product.require_advance_payment && (
            <div className="rounded-2xl bg-yellow-50 border border-yellow-200 px-4 py-3 text-xs text-yellow-800">
              {t.advancePaymentRequired}
            </div>
          )}

          {/* Error */}
          {error && (
            <p className="rounded-2xl bg-red-50 border border-red-200 px-4 py-3 text-sm text-red-600">
              {error}
            </p>
          )}

          {/* Add to cart */}
          <button
            onClick={handleAddToCart}
            disabled={!product.is_available}
            className={cn(
              "btn-primary w-full py-4 text-base",
              added && "!bg-green-500"
            )}
          >
            <ShoppingCart size={18} />
            {added ? "Added to Cart! ✓" : t.addToCart}
          </button>

          <p className="text-center text-xs text-accent-light">{t.freeDeliveryNote}</p>
        </div>
      </div>
    </div>
  );
}
