import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: "class",
  content: [
    "./src/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: "#FFF1F1",
          100: "#FFE1E1",
          200: "#FFC9C9",
          300: "#FFA8A8",
          400: "#FF8A8A",
          500: "#FF6B6B",
          600: "#F0504F",
          700: "#D63E3E",
          800: "#B33232",
          900: "#8C2828",
          DEFAULT: "#FF6B6B",
        },
        secondary: {
          DEFAULT: "#FFF5F5",
          dark: "#FFE9E9",
        },
        accent: {
          DEFAULT: "#2D3748",
          light: "#4A5568",
          50: "#F7FAFC",
          100: "#EDF2F7",
          200: "#E2E8F0",
        },
      },
      fontFamily: {
        display: ["var(--font-fraunces)", "Noto Sans Ethiopic", "serif"],
        sans: ["var(--font-jakarta)", "Noto Sans Ethiopic", "ui-sans-serif", "system-ui", "sans-serif"],
      },
      borderRadius: {
        "2xl": "1rem",
        "3xl": "1.5rem",
        "4xl": "2rem",
      },
      boxShadow: {
        soft: "0 8px 30px -8px rgba(45, 55, 72, 0.12)",
        card: "0 4px 16px -4px rgba(45, 55, 72, 0.08)",
        glow: "0 8px 30px -6px rgba(255, 107, 107, 0.35)",
      },
      backgroundImage: {
        "scallop-bottom":
          "radial-gradient(circle at 12px 0, transparent 12px, var(--scallop-color) 12.5px)",
      },
      backgroundSize: {
        scallop: "24px 24px",
      },
      keyframes: {
        "fade-up": {
          "0%": { opacity: "0", transform: "translateY(12px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
        "pop": {
          "0%": { transform: "scale(0.96)", opacity: "0.6" },
          "100%": { transform: "scale(1)", opacity: "1" },
        },
      },
      animation: {
        "fade-up": "fade-up 0.5s ease-out both",
        "pop": "pop 0.2s ease-out both",
      },
    },
  },
  plugins: [],
};

export default config;
