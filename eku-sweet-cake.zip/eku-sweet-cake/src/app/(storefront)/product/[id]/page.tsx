import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getProductById } from "@/actions/products";
import { ProductClient } from "@/components/product/ProductClient";

export const dynamic = "force-dynamic";

interface Props {
  params: Promise<{ id: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { id } = await params;
  const product = await getProductById(id);
  return { title: product?.name_en ?? "Product" };
}

export default async function ProductPage({ params }: Props) {
  const { id } = await params;
  const product = await getProductById(id);
  if (!product) notFound();

  return <ProductClient product={product} />;
}
