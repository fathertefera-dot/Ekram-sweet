-- =============================================================================
-- Eku Sweet Cake — Migration 0002: Row Level Security
-- =============================================================================
-- Security model:
--   * Catalog data (categories, products, images, prices) and `settings`
--     are PUBLIC READ — anyone can browse the storefront without logging in.
--   * Only users present in `public.admins` may write to catalog tables,
--     update order status, or change settings.
--   * `orders` / `order_items` are NEVER readable or writable by anonymous
--     clients directly. Guest checkout and the order-success lookup are
--     performed server-side with the Supabase service role key, which
--     bypasses RLS entirely (see src/lib/supabase/admin.ts).
-- =============================================================================

-- -----------------------------------------------------------------------
-- is_admin(): true if the currently authenticated user is in `admins`.
-- SECURITY DEFINER so it can read `admins` even though `admins` itself
-- has RLS enabled (avoids policy recursion).
-- -----------------------------------------------------------------------
create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public, pg_temp
stable
as $$
  select exists (
    select 1 from public.admins where id = auth.uid()
  );
$$;

grant execute on function public.is_admin() to anon, authenticated;

-- -----------------------------------------------------------------------
-- Enable RLS everywhere
-- -----------------------------------------------------------------------
alter table public.admins enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.product_images enable row level security;
alter table public.product_prices enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.settings enable row level security;

-- -----------------------------------------------------------------------
-- admins — a user may read only their own row (used by the admin UI to
-- display "logged in as ..."). No client-side writes.
-- -----------------------------------------------------------------------
drop policy if exists "Admins can read own row" on public.admins;
create policy "Admins can read own row"
  on public.admins for select
  to authenticated
  using (auth.uid() = id);

-- -----------------------------------------------------------------------
-- categories — public read, admin write
-- -----------------------------------------------------------------------
drop policy if exists "Public can read categories" on public.categories;
create policy "Public can read categories"
  on public.categories for select
  to anon, authenticated
  using (true);

drop policy if exists "Admins can insert categories" on public.categories;
create policy "Admins can insert categories"
  on public.categories for insert
  to authenticated
  with check (public.is_admin());

drop policy if exists "Admins can update categories" on public.categories;
create policy "Admins can update categories"
  on public.categories for update
  to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "Admins can delete categories" on public.categories;
create policy "Admins can delete categories"
  on public.categories for delete
  to authenticated
  using (public.is_admin());

-- -----------------------------------------------------------------------
-- products — public read, admin write
-- -----------------------------------------------------------------------
drop policy if exists "Public can read products" on public.products;
create policy "Public can read products"
  on public.products for select
  to anon, authenticated
  using (true);

drop policy if exists "Admins can insert products" on public.products;
create policy "Admins can insert products"
  on public.products for insert
  to authenticated
  with check (public.is_admin());

drop policy if exists "Admins can update products" on public.products;
create policy "Admins can update products"
  on public.products for update
  to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "Admins can delete products" on public.products;
create policy "Admins can delete products"
  on public.products for delete
  to authenticated
  using (public.is_admin());

-- -----------------------------------------------------------------------
-- product_images — public read, admin write
-- -----------------------------------------------------------------------
drop policy if exists "Public can read product images" on public.product_images;
create policy "Public can read product images"
  on public.product_images for select
  to anon, authenticated
  using (true);

drop policy if exists "Admins can insert product images" on public.product_images;
create policy "Admins can insert product images"
  on public.product_images for insert
  to authenticated
  with check (public.is_admin());

drop policy if exists "Admins can update product images" on public.product_images;
create policy "Admins can update product images"
  on public.product_images for update
  to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "Admins can delete product images" on public.product_images;
create policy "Admins can delete product images"
  on public.product_images for delete
  to authenticated
  using (public.is_admin());

-- -----------------------------------------------------------------------
-- product_prices — public read, admin write
-- -----------------------------------------------------------------------
drop policy if exists "Public can read product prices" on public.product_prices;
create policy "Public can read product prices"
  on public.product_prices for select
  to anon, authenticated
  using (true);

drop policy if exists "Admins can insert product prices" on public.product_prices;
create policy "Admins can insert product prices"
  on public.product_prices for insert
  to authenticated
  with check (public.is_admin());

drop policy if exists "Admins can update product prices" on public.product_prices;
create policy "Admins can update product prices"
  on public.product_prices for update
  to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "Admins can delete product prices" on public.product_prices;
create policy "Admins can delete product prices"
  on public.product_prices for delete
  to authenticated
  using (public.is_admin());

-- -----------------------------------------------------------------------
-- orders / order_items — admins only. Guest checkout + order confirmation
-- bypass RLS via the service role key on the server, so no anon policies
-- are defined here (default = deny).
-- -----------------------------------------------------------------------
drop policy if exists "Admins can read orders" on public.orders;
create policy "Admins can read orders"
  on public.orders for select
  to authenticated
  using (public.is_admin());

drop policy if exists "Admins can update orders" on public.orders;
create policy "Admins can update orders"
  on public.orders for update
  to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "Admins can read order items" on public.order_items;
create policy "Admins can read order items"
  on public.order_items for select
  to authenticated
  using (public.is_admin());

-- -----------------------------------------------------------------------
-- settings — public read (checkout needs payment method availability +
-- numbers), admin write.
-- -----------------------------------------------------------------------
drop policy if exists "Public can read settings" on public.settings;
create policy "Public can read settings"
  on public.settings for select
  to anon, authenticated
  using (true);

drop policy if exists "Admins can update settings" on public.settings;
create policy "Admins can update settings"
  on public.settings for update
  to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "Admins can insert settings" on public.settings;
create policy "Admins can insert settings"
  on public.settings for insert
  to authenticated
  with check (public.is_admin());

-- =============================================================================
-- Storage: "products" bucket
-- Public read (product photos shown on the storefront), admin-only writes.
-- =============================================================================
insert into storage.buckets (id, name, public)
values ('products', 'products', true)
on conflict (id) do nothing;

drop policy if exists "Public can view product images" on storage.objects;
create policy "Public can view product images"
  on storage.objects for select
  to anon, authenticated
  using (bucket_id = 'products');

drop policy if exists "Admins can upload product images" on storage.objects;
create policy "Admins can upload product images"
  on storage.objects for insert
  to authenticated
  with check (bucket_id = 'products' and public.is_admin());

drop policy if exists "Admins can update product images in storage" on storage.objects;
create policy "Admins can update product images in storage"
  on storage.objects for update
  to authenticated
  using (bucket_id = 'products' and public.is_admin())
  with check (bucket_id = 'products' and public.is_admin());

drop policy if exists "Admins can delete product images from storage" on storage.objects;
create policy "Admins can delete product images from storage"
  on storage.objects for delete
  to authenticated
  using (bucket_id = 'products' and public.is_admin());
